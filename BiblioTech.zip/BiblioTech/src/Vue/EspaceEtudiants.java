/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Vue;

import java.awt.Image;
import java.awt.Toolkit;
import java.io.File;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileNameExtensionFilter;
import Modele.*;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.table.DefaultTableModel;
import java.awt.Color;
import java.awt.print.PrinterException;
import java.text.MessageFormat;
import java.text.SimpleDateFormat;
import javax.swing.JTable;

/**
 *
 * @author ASUS VIVOBOOK
 */
public class EspaceEtudiants extends javax.swing.JFrame {

    /**
     * Creates new form EspaceEtdiants
     */
    ConnectBdd connect = new ConnectBdd();
    PreparedStatement pst,pst1;
    DefaultTableModel mo = new DefaultTableModel();
    DefaultTableModel mr = new DefaultTableModel();
    DefaultTableModel memp = new DefaultTableModel();
    ResultSet rs;
    ConnectOuv co = new ConnectOuv();
    ConnectReservation cr = new ConnectReservation();
    ConnectEmprunt cemp = new ConnectEmprunt();
    ConnectPenal cp = new ConnectPenal();
    ConnexEtudiant cet = new ConnexEtudiant();

    public EspaceEtudiants() {
        initComponents();
        setLocationRelativeTo(this);
        info.setVisible(false);
        listeouvrage.setVisible(false);
        reservation.setVisible(false);
        premierplan.setVisible(true);
        reservationpanel.setVisible(false);
        empruntpanel.setVisible(false);
        prolongation.setVisible(false);
        try {
            pst = cp.cop.connexBd().prepareStatement("select * from penalite");
            cp.rsp = pst.executeQuery();
            pst1 = cet.connex.connexBd().prepareStatement("select * from etudiant where email=?");
            pst1.setString(1, Authentification.jid.getText());
            cet.rset = pst1.executeQuery();

            while (cp.rsp.next() && cet.rset.next()) {
                
                if (cp.rsp.getObject("matricule").equals(cet.rset.getObject("matricule"))) {
                    JOptionPane.showMessageDialog(this, "VOTRE COMPTE EST SUSPENDU POUR "
                            + cp.rsp.getObject("nbr_jour") + " jours\n veuillez restituez les anciens emprunts");
                    baffichre.setEnabled(false);
                    brech.setEnabled(false);
                    bdprolon.setEnabled(false);
                    baffich.setEnabled(false);
                } else {
                    System.out.print(cp.rsp.getObject("matricule")+"\nxxxx");
                    System.out.print(cet.rset.getObject("matricule"));

                    //JOptionPane.showMessageDialog(this, "erreur");
                    baffichre.setEnabled(true);
                    brech.setEnabled(true);
                    bdprolon.setEnabled(true);
                    baffich.setEnabled(true);
                }

            }
        } catch (SQLException ex) {
            Logger.getLogger(EspaceEtudiants.class.getName()).log(Level.SEVERE, null, ex);
        }
        setTitle("Espace Etudiant");
        setIcon();
        mo.addColumn("Référence");
        mo.addColumn("Intitulé");
        mo.addColumn("Auteur");
        mo.addColumn("Edition");
        mo.addColumn("Année d'edition");
        mo.addColumn("Photo");
        mo.addColumn("Spécialité");
        mo.addColumn("Description");
        mo.addColumn("quantite");
        tabouvrech.setModel(mo);

    }

    public void actureserv() {
        try {
            mr.setRowCount(0);
            mr.setColumnCount(0);
            mr.addColumn("Matricule");
            mr.addColumn("Référence");
            mr.addColumn("Date");
            mr.addColumn("Nom");
            mr.addColumn("Prénom");
            pst = cr.conreserv.connexBd().prepareStatement("select * from reservation where matric=?");
            pst.setString(1, lmat.getText());
            cr.rsreserv = pst.executeQuery();
            while (cr.rsreserv.next()) {
                mr.addRow(new Object[]{
                    cr.rsreserv.getObject("matric"),
                    cr.rsreserv.getObject("refouv"),
                    cr.rsreserv.getObject("date_resv"),
                    cr.rsreserv.getObject("nom"),
                    cr.rsreserv.getObject("prenom"),});
            }
            tabreserv.setModel(mr);
        } catch (SQLException ex) {
            Logger.getLogger(EspaceAssistant.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void affichageouv(int ls) {
        lref.setText(tabouvrech.getValueAt(ls, 0).toString());
        lintitule.setText(tabouvrech.getValueAt(ls, 1).toString());
        lauteur.setText(tabouvrech.getValueAt(ls, 2).toString());
        ledit.setText(tabouvrech.getValueAt(ls, 3).toString());
        lanne.setText(tabouvrech.getValueAt(ls, 4).toString());

        //ca marche pas
        //recuperer la photo de la jtable
        try {

            pst = connect.connexBd().prepareStatement("select photo from ouvrages where reference=?");
            pst.setString(1, tabouvrech.getValueAt(ls, 0).toString());
            rs = pst.executeQuery();
            while (rs.next()) {
                byte tabimg[] = rs.getBytes("photo");
                ImageIcon photo = new ImageIcon(tabimg);
                Image photorec = photo.getImage().getScaledInstance(lphoto.getWidth(), lphoto.getHeight(), Image.SCALE_SMOOTH);
                ImageIcon photorecf = new ImageIcon(photorec);
                lphoto.setIcon(photorecf);
            }

        } catch (SQLException ex) {
            Logger.getLogger(EspaceEtudiants.class.getName()).log(Level.SEVERE, null, ex);
        }
        lfiliere.setText(tabouvrech.getValueAt(ls, 6).toString());
        jadesrip.setText(tabouvrech.getValueAt(ls, 7).toString());

    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        info = new javax.swing.JPanel();
        lintitule = new javax.swing.JLabel();
        intitule = new javax.swing.JLabel();
        auteur = new javax.swing.JLabel();
        lauteur = new javax.swing.JLabel();
        lfiliere = new javax.swing.JLabel();
        filiere = new javax.swing.JLabel();
        edition = new javax.swing.JLabel();
        ledit = new javax.swing.JLabel();
        lanne = new javax.swing.JLabel();
        annee = new javax.swing.JLabel();
        description = new javax.swing.JLabel();
        panelphoto = new javax.swing.JPanel();
        lphoto = new javax.swing.JLabel();
        jadescrip = new javax.swing.JScrollPane();
        jadesrip = new javax.swing.JTextArea();
        jLabel1 = new javax.swing.JLabel();
        lref = new javax.swing.JLabel();
        dispo = new javax.swing.JLabel();
        empruntpanel = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        tabemp = new javax.swing.JTable();
        reservationpanel = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tabreserv = new javax.swing.JTable();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        recherche = new javax.swing.JPanel();
        cbsearch = new javax.swing.JComboBox();
        jtrech = new javax.swing.JTextField();
        brech = new javax.swing.JButton();
        cbfil = new javax.swing.JComboBox();
        baffichre = new javax.swing.JButton();
        baffich = new javax.swing.JButton();
        bdprolon = new javax.swing.JButton();
        listeouvrage = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabouvrech = new javax.swing.JTable();
        breserver = new javax.swing.JButton();
        bexit = new javax.swing.JButton();
        lnom = new javax.swing.JLabel();
        lpnom = new javax.swing.JLabel();
        lmat = new javax.swing.JLabel();
        ltit = new javax.swing.JLabel();
        firstplan = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        prolongation = new javax.swing.JPanel();
        jLabel13 = new javax.swing.JLabel();
        bpro = new javax.swing.JButton();
        jScrollPane4 = new javax.swing.JScrollPane();
        motif = new javax.swing.JTextArea();
        datp = new com.toedter.calendar.JDateChooser();
        jLabel14 = new javax.swing.JLabel();
        reservation = new javax.swing.JPanel();
        nom = new javax.swing.JLabel();
        pnom = new javax.swing.JLabel();
        matricule = new javax.swing.JLabel();
        datereser = new com.toedter.calendar.JDateChooser();
        jLabel4 = new javax.swing.JLabel();
        jtnom = new javax.swing.JTextField();
        jtpnom = new javax.swing.JTextField();
        benvoie = new javax.swing.JButton();
        jtmat = new javax.swing.JTextField();
        reserveffec = new javax.swing.JLabel();
        premierplan = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        disco = new javax.swing.JLabel();
        lfond = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        info.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED), "Informations :", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Calibri", 1, 36), new java.awt.Color(0, 0, 204))); // NOI18N
        info.setOpaque(false);
        info.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lintitule.setFont(new java.awt.Font("Calibri", 3, 24)); // NOI18N
        lintitule.setForeground(new java.awt.Color(0, 0, 204));
        lintitule.setText("...........");
        info.add(lintitule, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 110, -1, -1));

        intitule.setFont(new java.awt.Font("Calibri", 3, 24)); // NOI18N
        intitule.setForeground(new java.awt.Color(0, 0, 204));
        intitule.setText("Intitulé :");
        info.add(intitule, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 110, -1, -1));

        auteur.setFont(new java.awt.Font("Calibri", 3, 24)); // NOI18N
        auteur.setForeground(new java.awt.Color(0, 0, 204));
        auteur.setText("Auteur :");
        info.add(auteur, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 160, -1, -1));

        lauteur.setFont(new java.awt.Font("Calibri", 3, 24)); // NOI18N
        lauteur.setForeground(new java.awt.Color(0, 0, 204));
        lauteur.setText("..........");
        info.add(lauteur, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 160, -1, -1));

        lfiliere.setFont(new java.awt.Font("Calibri", 3, 24)); // NOI18N
        lfiliere.setForeground(new java.awt.Color(0, 0, 204));
        lfiliere.setText("..........");
        info.add(lfiliere, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 210, -1, -1));

        filiere.setFont(new java.awt.Font("Calibri", 3, 24)); // NOI18N
        filiere.setForeground(new java.awt.Color(0, 0, 204));
        filiere.setText("Filière :");
        info.add(filiere, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 210, -1, -1));

        edition.setFont(new java.awt.Font("Calibri", 3, 24)); // NOI18N
        edition.setForeground(new java.awt.Color(0, 0, 204));
        edition.setText("Edition :");
        info.add(edition, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 260, -1, -1));

        ledit.setFont(new java.awt.Font("Calibri", 3, 24)); // NOI18N
        ledit.setForeground(new java.awt.Color(0, 0, 204));
        ledit.setText("...........");
        info.add(ledit, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 260, -1, -1));

        lanne.setFont(new java.awt.Font("Calibri", 3, 24)); // NOI18N
        lanne.setForeground(new java.awt.Color(0, 0, 204));
        lanne.setText("..........");
        info.add(lanne, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 310, -1, -1));

        annee.setFont(new java.awt.Font("Calibri", 3, 24)); // NOI18N
        annee.setForeground(new java.awt.Color(0, 0, 204));
        annee.setText("Année :");
        info.add(annee, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 310, -1, -1));

        description.setFont(new java.awt.Font("Calibri", 3, 24)); // NOI18N
        description.setForeground(new java.awt.Color(0, 0, 204));
        description.setText("Description :");
        info.add(description, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 370, -1, -1));

        panelphoto.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        panelphoto.setFocusCycleRoot(true);
        panelphoto.setOpaque(false);
        panelphoto.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        panelphoto.add(lphoto, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 200, 230));

        info.add(panelphoto, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 60, 220, 250));

        jadesrip.setColumns(20);
        jadesrip.setRows(5);
        jadescrip.setViewportView(jadesrip);

        info.add(jadescrip, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 420, 610, 140));

        jLabel1.setFont(new java.awt.Font("Calibri", 3, 20)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 204));
        jLabel1.setText("Réference :");
        info.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 70, -1, -1));

        lref.setFont(new java.awt.Font("Calibri", 3, 24)); // NOI18N
        lref.setForeground(new java.awt.Color(0, 0, 204));
        lref.setText("...........");
        info.add(lref, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 70, -1, -1));

        dispo.setFont(new java.awt.Font("Calibri", 3, 24)); // NOI18N
        dispo.setForeground(new java.awt.Color(204, 0, 0));
        info.add(dispo, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 380, 230, 30));

        getContentPane().add(info, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 130, 750, 590));

        empruntpanel.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED), "Liste des  ouvrages empruntés", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Calibri", 3, 18), new java.awt.Color(0, 0, 204))); // NOI18N
        empruntpanel.setOpaque(false);

        tabemp.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane3.setViewportView(tabemp);

        javax.swing.GroupLayout empruntpanelLayout = new javax.swing.GroupLayout(empruntpanel);
        empruntpanel.setLayout(empruntpanelLayout);
        empruntpanelLayout.setHorizontalGroup(
            empruntpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(empruntpanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(19, Short.MAX_VALUE))
        );
        empruntpanelLayout.setVerticalGroup(
            empruntpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(empruntpanelLayout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 343, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(98, Short.MAX_VALUE))
        );

        getContentPane().add(empruntpanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 460, 500, 500));

        reservationpanel.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED), "Reservations Effectuées", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Calibri", 3, 20), new java.awt.Color(0, 0, 204))); // NOI18N
        reservationpanel.setOpaque(false);

        tabreserv.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        jScrollPane2.setViewportView(tabreserv);

        jButton1.setFont(new java.awt.Font("Calibri", 3, 20)); // NOI18N
        jButton1.setForeground(new java.awt.Color(0, 0, 204));
        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8_delete_26px.png"))); // NOI18N
        jButton1.setText("Annuler");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setFont(new java.awt.Font("Calibri", 3, 20)); // NOI18N
        jButton2.setForeground(new java.awt.Color(0, 0, 204));
        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/print.png"))); // NOI18N
        jButton2.setText("Imprimer");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout reservationpanelLayout = new javax.swing.GroupLayout(reservationpanel);
        reservationpanel.setLayout(reservationpanelLayout);
        reservationpanelLayout.setHorizontalGroup(
            reservationpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(reservationpanelLayout.createSequentialGroup()
                .addContainerGap(19, Short.MAX_VALUE)
                .addGroup(reservationpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, reservationpanelLayout.createSequentialGroup()
                        .addComponent(jButton2)
                        .addGap(20, 20, 20)
                        .addComponent(jButton1)))
                .addContainerGap())
        );
        reservationpanelLayout.setVerticalGroup(
            reservationpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(reservationpanelLayout.createSequentialGroup()
                .addGap(51, 51, 51)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 297, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 71, Short.MAX_VALUE)
                .addGroup(reservationpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton2)
                    .addComponent(jButton1))
                .addContainerGap())
        );

        getContentPane().add(reservationpanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 460, 500, 500));

        recherche.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED), "Option de rechreche :", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Calibri", 1, 36), new java.awt.Color(0, 0, 204))); // NOI18N
        recherche.setForeground(new java.awt.Color(0, 0, 153));
        recherche.setOpaque(false);
        recherche.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        cbsearch.setFont(new java.awt.Font("Calibri", 1, 24)); // NOI18N
        cbsearch.setForeground(new java.awt.Color(0, 0, 204));
        cbsearch.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Filiere", "Intitule" }));
        cbsearch.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                cbsearchMouseClicked(evt);
            }
        });
        cbsearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbsearchActionPerformed(evt);
            }
        });
        recherche.add(cbsearch, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 80, 290, -1));

        jtrech.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jtrechActionPerformed(evt);
            }
        });
        recherche.add(jtrech, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 160, 290, 40));

        brech.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/search.png"))); // NOI18N
        brech.setToolTipText("");
        brech.setOpaque(false);
        brech.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                brechActionPerformed(evt);
            }
        });
        recherche.add(brech, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 140, 90, 60));

        cbfil.setFont(new java.awt.Font("Calibri", 1, 24)); // NOI18N
        cbfil.setForeground(new java.awt.Color(0, 0, 204));
        cbfil.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Architecture", "Automatique", "Chimie", "Eléctronique", "Géologie", "Informatique", "Mathematique", "Mécanique", "Médecine", "Physique", "Réseaux", "Statistique" }));
        recherche.add(cbfil, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 120, 290, 40));

        baffichre.setFont(new java.awt.Font("Calibri", 3, 20)); // NOI18N
        baffichre.setForeground(new java.awt.Color(0, 0, 204));
        baffichre.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/reserver.png"))); // NOI18N
        baffichre.setText("Reservation");
        baffichre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                baffichreActionPerformed(evt);
            }
        });
        recherche.add(baffichre, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 210, 170, 40));

        baffich.setFont(new java.awt.Font("Calibri", 3, 20)); // NOI18N
        baffich.setForeground(new java.awt.Color(0, 0, 204));
        baffich.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/emprunt.png"))); // NOI18N
        baffich.setText("Emprunt");
        baffich.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                baffichActionPerformed(evt);
            }
        });
        recherche.add(baffich, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 260, 170, 40));

        bdprolon.setFont(new java.awt.Font("Calibri", 3, 18)); // NOI18N
        bdprolon.setForeground(new java.awt.Color(0, 0, 204));
        bdprolon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/request.png"))); // NOI18N
        bdprolon.setText("Demande Prolongation");
        bdprolon.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bdprolonActionPerformed(evt);
            }
        });
        recherche.add(bdprolon, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 259, 260, 40));

        getContentPane().add(recherche, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 140, 500, 310));

        listeouvrage.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED), "Liste d'ouvrage recherchés", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Calibri", 1, 36), new java.awt.Color(0, 0, 204))); // NOI18N
        listeouvrage.setOpaque(false);
        listeouvrage.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        tabouvrech.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        tabouvrech.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tabouvrechMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tabouvrech);

        listeouvrage.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(24, 78, -1, 367));

        breserver.setFont(new java.awt.Font("Calibri", 3, 20)); // NOI18N
        breserver.setForeground(new java.awt.Color(0, 0, 204));
        breserver.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/reserver.png"))); // NOI18N
        breserver.setText("Reserver");
        breserver.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                breserverActionPerformed(evt);
            }
        });
        listeouvrage.add(breserver, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 460, -1, 41));

        getContentPane().add(listeouvrage, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 450, 500, 510));

        bexit.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/exit.png"))); // NOI18N
        bexit.setOpaque(false);
        bexit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bexitActionPerformed(evt);
            }
        });
        getContentPane().add(bexit, new org.netbeans.lib.awtextra.AbsoluteConstraints(1390, 890, 80, 70));

        lnom.setFont(new java.awt.Font("Calibri", 1, 24)); // NOI18N
        lnom.setForeground(new java.awt.Color(255, 255, 255));
        lnom.setText("...................");
        getContentPane().add(lnom, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 70, -1, -1));

        lpnom.setFont(new java.awt.Font("Calibri", 1, 24)); // NOI18N
        lpnom.setForeground(new java.awt.Color(255, 255, 255));
        lpnom.setText("...................");
        getContentPane().add(lpnom, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 70, -1, -1));

        lmat.setFont(new java.awt.Font("Calibri", 1, 24)); // NOI18N
        lmat.setForeground(new java.awt.Color(255, 255, 255));
        lmat.setText("...................");
        getContentPane().add(lmat, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 70, -1, -1));

        ltit.setFont(new java.awt.Font("Calibri", 1, 48)); // NOI18N
        ltit.setForeground(new java.awt.Color(255, 255, 255));
        ltit.setText("ESPACE ETUDIANT");
        getContentPane().add(ltit, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 20, -1, -1));

        firstplan.setOpaque(false);

        jLabel3.setFont(new java.awt.Font("Calibri", 3, 48)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 0, 204));
        jLabel3.setText("BIBLIO-TECH");

        jLabel5.setFont(new java.awt.Font("Calibri", 3, 20)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(0, 0, 204));
        jLabel5.setText("Vous disposez de trois (03) jours pour venir récupérer ");

        jLabel6.setFont(new java.awt.Font("Calibri", 3, 20)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(0, 0, 204));
        jLabel6.setText("les ouvrages reserver a partir de cette application.");

        jLabel7.setFont(new java.awt.Font("Calibri", 3, 20)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(0, 0, 204));
        jLabel7.setText("A partir de la date de reservartion vous disposez de 15");

        jLabel8.setFont(new java.awt.Font("Calibri", 3, 20)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(0, 0, 204));
        jLabel8.setText(" jours pour rendre les ouvrages empruntés. ");

        jLabel9.setFont(new java.awt.Font("Calibri", 3, 20)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(0, 0, 204));
        jLabel9.setText("Depassez ce délais, vous ne pourrez plus reserver (et biensur ");

        jLabel10.setFont(new java.awt.Font("Calibri", 3, 20)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(0, 0, 204));
        jLabel10.setText("ne plus emprunter). ");

        jLabel11.setFont(new java.awt.Font("Calibri", 3, 20)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(0, 0, 204));
        jLabel11.setText("Chaque jour de retard sera compter comme trois jours.");

        jLabel12.setFont(new java.awt.Font("Calibri", 3, 20)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(0, 0, 204));
        jLabel12.setText("MERCI.");

        javax.swing.GroupLayout firstplanLayout = new javax.swing.GroupLayout(firstplan);
        firstplan.setLayout(firstplanLayout);
        firstplanLayout.setHorizontalGroup(
            firstplanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, firstplanLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jLabel12)
                .addGap(196, 196, 196))
            .addGroup(firstplanLayout.createSequentialGroup()
                .addGroup(firstplanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(firstplanLayout.createSequentialGroup()
                        .addGap(124, 124, 124)
                        .addComponent(jLabel3))
                    .addGroup(firstplanLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel6))
                    .addGroup(firstplanLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel8))
                    .addGroup(firstplanLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel9))
                    .addGroup(firstplanLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel10))
                    .addGroup(firstplanLayout.createSequentialGroup()
                        .addGap(39, 39, 39)
                        .addGroup(firstplanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel7)
                            .addComponent(jLabel5)))
                    .addGroup(firstplanLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel11)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        firstplanLayout.setVerticalGroup(
            firstplanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, firstplanLayout.createSequentialGroup()
                .addGap(0, 41, Short.MAX_VALUE)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel6)
                .addGap(18, 18, 18)
                .addComponent(jLabel7)
                .addGap(7, 7, 7)
                .addComponent(jLabel8)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel9)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel10)
                .addGap(54, 54, 54)
                .addComponent(jLabel11)
                .addGap(92, 92, 92)
                .addComponent(jLabel12))
        );

        getContentPane().add(firstplan, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 430, 540, 540));

        prolongation.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED), "Demande de prolongation", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Calibri", 3, 18), new java.awt.Color(0, 0, 204))); // NOI18N
        prolongation.setAutoscrolls(true);
        prolongation.setOpaque(false);

        jLabel13.setFont(new java.awt.Font("Calibri", 3, 20)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(0, 0, 204));
        jLabel13.setText("Motif :");

        bpro.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/prolongation.png"))); // NOI18N
        bpro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bproActionPerformed(evt);
            }
        });

        motif.setColumns(20);
        motif.setRows(5);
        jScrollPane4.setViewportView(motif);

        jLabel14.setFont(new java.awt.Font("Calibri", 3, 20)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(0, 0, 204));
        jLabel14.setText("Jusqu'à :");

        javax.swing.GroupLayout prolongationLayout = new javax.swing.GroupLayout(prolongation);
        prolongation.setLayout(prolongationLayout);
        prolongationLayout.setHorizontalGroup(
            prolongationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(prolongationLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(prolongationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel13)
                    .addComponent(jLabel14))
                .addGap(88, 88, 88)
                .addGroup(prolongationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(prolongationLayout.createSequentialGroup()
                        .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 266, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 277, Short.MAX_VALUE))
                    .addGroup(prolongationLayout.createSequentialGroup()
                        .addComponent(datp, javax.swing.GroupLayout.PREFERRED_SIZE, 176, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(bpro)))
                .addContainerGap())
        );
        prolongationLayout.setVerticalGroup(
            prolongationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(prolongationLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(prolongationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel13)
                    .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20)
                .addGroup(prolongationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(prolongationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel14)
                        .addComponent(bpro))
                    .addComponent(datp, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        getContentPane().add(prolongation, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 740, 750, 210));

        reservation.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED), "Veuillez remplir les champs suivants", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Calibri", 3, 24), new java.awt.Color(0, 0, 204))); // NOI18N
        reservation.setOpaque(false);

        nom.setFont(new java.awt.Font("Calibri", 1, 18)); // NOI18N
        nom.setText("Nom :");

        pnom.setFont(new java.awt.Font("Calibri", 1, 18)); // NOI18N
        pnom.setText("Prenom :");

        matricule.setFont(new java.awt.Font("Calibri", 1, 18)); // NOI18N
        matricule.setText("Matricule :");

        jLabel4.setFont(new java.awt.Font("Calibri", 1, 18)); // NOI18N
        jLabel4.setText("Date :");

        benvoie.setFont(new java.awt.Font("Calibri", 3, 18)); // NOI18N
        benvoie.setForeground(new java.awt.Color(0, 51, 153));
        benvoie.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/send.png"))); // NOI18N
        benvoie.setText("Envoyer");
        benvoie.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                benvoieActionPerformed(evt);
            }
        });

        reserveffec.setFont(new java.awt.Font("Calibri", 3, 18)); // NOI18N
        reserveffec.setForeground(new java.awt.Color(204, 0, 0));

        javax.swing.GroupLayout reservationLayout = new javax.swing.GroupLayout(reservation);
        reservation.setLayout(reservationLayout);
        reservationLayout.setHorizontalGroup(
            reservationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(reservationLayout.createSequentialGroup()
                .addGap(4, 4, 4)
                .addGroup(reservationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(matricule)
                    .addComponent(pnom)
                    .addComponent(nom))
                .addGap(20, 20, 20)
                .addGroup(reservationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jtnom, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(reservationLayout.createSequentialGroup()
                        .addGroup(reservationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jtmat)
                            .addComponent(jtpnom, javax.swing.GroupLayout.DEFAULT_SIZE, 140, Short.MAX_VALUE))
                        .addGap(86, 86, 86)
                        .addComponent(jLabel4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(datereser, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(213, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, reservationLayout.createSequentialGroup()
                .addContainerGap(342, Short.MAX_VALUE)
                .addComponent(reserveffec)
                .addGap(260, 260, 260)
                .addComponent(benvoie)
                .addContainerGap())
        );
        reservationLayout.setVerticalGroup(
            reservationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(reservationLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(reservationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(reserveffec)
                    .addGroup(reservationLayout.createSequentialGroup()
                        .addGroup(reservationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(reservationLayout.createSequentialGroup()
                                .addGap(3, 3, 3)
                                .addComponent(nom))
                            .addComponent(jtnom, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(reservationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(reservationLayout.createSequentialGroup()
                                .addGap(21, 21, 21)
                                .addComponent(pnom))
                            .addGroup(reservationLayout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addComponent(jtpnom, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(17, 17, 17)
                        .addGroup(reservationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(datereser, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(reservationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(reservationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(matricule)
                                    .addComponent(jtmat, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addComponent(jLabel4)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(benvoie)))
                .addGap(166, 166, 166))
        );

        getContentPane().add(reservation, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 730, 750, 220));

        premierplan.setOpaque(false);

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/OPEN-BOOK.png"))); // NOI18N

        javax.swing.GroupLayout premierplanLayout = new javax.swing.GroupLayout(premierplan);
        premierplan.setLayout(premierplanLayout);
        premierplanLayout.setHorizontalGroup(
            premierplanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(premierplanLayout.createSequentialGroup()
                .addGap(69, 69, 69)
                .addComponent(jLabel2)
                .addContainerGap(136, Short.MAX_VALUE))
        );
        premierplanLayout.setVerticalGroup(
            premierplanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(premierplanLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2)
                .addContainerGap(77, Short.MAX_VALUE))
        );

        getContentPane().add(premierplan, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 110, 790, 710));

        disco.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8_logout_rounded_down_30px_1.png"))); // NOI18N
        disco.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        disco.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                discoMouseClicked(evt);
            }
        });
        getContentPane().add(disco, new org.netbeans.lib.awtextra.AbsoluteConstraints(1440, 20, -1, -1));

        lfond.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/formReservation_1.png"))); // NOI18N
        getContentPane().add(lfond, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void bexitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bexitActionPerformed
        // TODO add your handling code here:
        dispose();
    }//GEN-LAST:event_bexitActionPerformed

    private void breserverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_breserverActionPerformed
        firstplan.setVisible(false);
        reservation.setVisible(true);
        premierplan.setVisible(false);
        prolongation.setVisible(false);

        jtnom.setText(lnom.getText());
        jtnom.setEditable(false);
        jtpnom.setText(lpnom.getText());
        jtpnom.setEditable(false);
        jtmat.setText(lmat.getText());
        jtmat.setEditable(false);

    }//GEN-LAST:event_breserverActionPerformed

    private void baffichActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_baffichActionPerformed
        firstplan.setVisible(false);
        listeouvrage.setVisible(false);
        reservationpanel.setVisible(false);
        empruntpanel.setVisible(true);
        try {
            memp.setRowCount(0);
            memp.setColumnCount(0);
            memp.addColumn("Matricule");
            memp.addColumn("Référence");
            memp.addColumn("Date");
            memp.addColumn("Nom");
            memp.addColumn("Prénom");
            pst = cemp.coemp.connexBd().prepareStatement("select * from emprunt where matricule=?");
            pst.setString(1, lmat.getText());
            cemp.rsemp = pst.executeQuery();
            while (cemp.rsemp.next()) {
                memp.addRow(new Object[]{
                    cemp.rsemp.getObject("matricule"),
                    cemp.rsemp.getObject("ref"),
                    cemp.rsemp.getObject("date_empr"),
                    cemp.rsemp.getObject("nom"),
                    cemp.rsemp.getObject("prenom")
                });
            }
            tabemp.setModel(memp);
        } catch (SQLException ex) {
            Logger.getLogger(EspaceAssistant.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_baffichActionPerformed

    private void benvoieActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_benvoieActionPerformed
        try {
            pst = connect.connexBd().prepareStatement("select date_empr from emprunt where matricule=?");
            pst.setString(1, lmat.getText());
            rs = pst.executeQuery();
            SimpleDateFormat f = new SimpleDateFormat("yyyy/MM/dd");
            String dr = f.format(datereser.getDate());
            if (!rs.next()) {
                if (dispo.getText().equals("disponible")) {
                    if (tabouvrech.getSelectedRowCount() > 1) {
                        for (int i = 0; i < tabouvrech.getSelectedRowCount(); i++) {
                            try {
                                pst = connect.connexBd().prepareStatement("insert into reservation (matric,refouv,"
                                        + "date_resv,nom,prenom)values(?,?,?,?,?)");
                                pst.setString(1, jtmat.getText());
                                pst.setString(2, (String) tabouvrech.getValueAt(tabouvrech.getSelectedRow() + i, 0));
                                SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
                                String an = df.format(datereser.getDate());
                                pst.setString(3, an);
                                pst.setString(4, jtnom.getText());
                                pst.setString(5, jtpnom.getText());
                                pst.executeUpdate();
                            } catch (SQLException ex) {
                                Logger.getLogger(EspaceEtudiants.class.getName()).log(Level.SEVERE, null, ex);

                            }

                        }

                    } else {
                        try {
                            pst = connect.connexBd().prepareStatement("insert into reservation (matric,refouv,"
                                    + "date_resv,nom,prenom)values(?,?,?,?,?)");
                            pst.setString(1, jtmat.getText());
                            pst.setString(2, (String) tabouvrech.getValueAt(tabouvrech.getSelectedRow(), 0));
                            SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");//le m doit etre en maj
                            String an = df.format(datereser.getDate());
                            pst.setString(3, an);
                            pst.setString(4, jtnom.getText());
                            pst.setString(5, jtpnom.getText());
                            pst.executeUpdate();

                        } catch (SQLException ex) {
                            Logger.getLogger(EspaceEtudiants.class.getName()).log(Level.SEVERE, null, ex);

                        }
                        JOptionPane.showMessageDialog(this, "La reservation a été effectuée avec succé");
                        System.err.println("erreur");

                    }

                } else {
                    JOptionPane.showMessageDialog(this, "Ce livre n'est pas disponible");
                }

            } else {
              //  while (rs.next()) {
                    System.out.println(rs.getObject("date_empr"));

                    if ((Integer.parseInt(dr.substring(8)) - Integer.parseInt(rs.getObject("date_empr").toString().substring(8))) > 15) {
                        benvoie.setEnabled(false);
                        // datereser.setEnabled(false);
                        reserveffec.setText("Veuillez restituer les anciens emprunts");
                    } else {
                        if (dispo.getText().equals("disponible")) {
                            if (tabouvrech.getSelectedRowCount() > 1) {
                                for (int i = 0; i < tabouvrech.getSelectedRowCount(); i++) {
                                    try {
                                        pst = connect.connexBd().prepareStatement("insert into reservation (matric,refouv,"
                                                + "date_resv,nom,prenom)values(?,?,?,?,?)");
                                        pst.setString(1, jtmat.getText());
                                        pst.setString(2, (String) tabouvrech.getValueAt(tabouvrech.getSelectedRow() + i, 0));
                                        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
                                        String an = df.format(datereser.getDate());
                                        pst.setString(3, an);
                                        pst.setString(4, jtnom.getText());
                                        pst.setString(5, jtpnom.getText());
                                        pst.executeUpdate();
                                    } catch (SQLException ex) {
                                        Logger.getLogger(EspaceEtudiants.class.getName()).log(Level.SEVERE, null, ex);

                                    }

                                }

                            } else {
                                try {
                                    pst = connect.connexBd().prepareStatement("insert into reservation (matric,refouv,"
                                            + "date_resv,nom,prenom)values(?,?,?,?,?)");
                                    pst.setString(1, jtmat.getText());
                                    pst.setString(2, (String) tabouvrech.getValueAt(tabouvrech.getSelectedRow(), 0));
                                    SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");//le m doit etre en maj
                                    String an = df.format(datereser.getDate());
                                    pst.setString(3, an);
                                    pst.setString(4, jtnom.getText());
                                    pst.setString(5, jtpnom.getText());
                                    pst.executeUpdate();

                                } catch (SQLException ex) {
                                    Logger.getLogger(EspaceEtudiants.class.getName()).log(Level.SEVERE, null, ex);

                                }
                                JOptionPane.showMessageDialog(this, "La reservation a été effectuée avec succé");
                                System.err.println("erreur");

                            }

                        } else {
                            JOptionPane.showMessageDialog(this, "Ce livre n'est pas disponible");
                        }

                    }
                }
       //     }
        } catch (SQLException ex) {
            Logger.getLogger(EspaceEtudiants.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_benvoieActionPerformed

    private void brechActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_brechActionPerformed
        reservationpanel.setVisible(false);
        empruntpanel.setVisible(false);
        firstplan.setVisible(false);
        listeouvrage.setVisible(true);
        if (cbsearch.getSelectedItem().equals("Filiere")) {

            mo.setRowCount(0);
            try {
                pst = connect.connexBd().prepareStatement("select * from ouvrages where categorie=?");
                pst.setString(1, cbfil.getSelectedItem().toString());
                rs = pst.executeQuery();
                while (rs.next()) {
                    mo.addRow(new Object[]{
                        rs.getObject("reference"),
                        rs.getObject("intitule"),
                        rs.getObject("auteur"),
                        rs.getObject("edition"),
                        rs.getObject("annee_edi"),
                        rs.getBlob("photo"),
                        rs.getObject("categorie"),
                        rs.getObject("description"),
                        rs.getObject("quantite")});
                }
                tabouvrech.setModel(mo);
                if (mo.getRowCount() == 0) {
                    JOptionPane.showMessageDialog(this, "l'ouvrage n'existe pas");
                } else {
                    affichageouv(0);
                }
            } catch (SQLException ex) {
                Logger.getLogger(EspaceEtudiants.class.getName()).log(Level.SEVERE, null, ex);
            }
        } else {

            mo.setRowCount(0);
            try {
                pst = connect.connexBd().prepareStatement("select * from ouvrages where intitule=?");
                pst.setString(1, jtrech.getText());
                rs = pst.executeQuery();
                while (rs.next()) {
                    mo.addRow(new Object[]{
                        rs.getObject("reference"),
                        rs.getObject("intitule"),
                        rs.getObject("auteur"),
                        rs.getObject("edition"),
                        rs.getObject("annee_edi"),
                        rs.getBlob("photo"),
                        rs.getObject("categorie"),
                        rs.getObject("description"),
                        rs.getObject("quantite")});
                }
                tabouvrech.setModel(mo);
                if (mo.getRowCount() == 0) {
                    JOptionPane.showMessageDialog(this, "l'ouvrage n'existe pas");
                } else {
                    affichageouv(0);
                }
            } catch (SQLException ex) {
                Logger.getLogger(EspaceEtudiants.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }//GEN-LAST:event_brechActionPerformed

    private void jtrechActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jtrechActionPerformed
        // TODO add your handling code here:

    }//GEN-LAST:event_jtrechActionPerformed

    private void cbsearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbsearchActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cbsearchActionPerformed

    private void tabouvrechMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tabouvrechMouseClicked
        // TODO add your handling code here:
        premierplan.setVisible(false);
        info.setVisible(true);
        affichageouv(tabouvrech.getSelectedRow());
        if ((int) tabouvrech.getValueAt(tabouvrech.getSelectedRow(), 8) == 0) {
            dispo.setText("non-disponible");
            dispo.setForeground(Color.red);
        } else {
            dispo.setText("disponible");
            dispo.setForeground(Color.green);
        }
    }//GEN-LAST:event_tabouvrechMouseClicked

    private void discoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_discoMouseClicked
        // TODO add your handling code here:
        dispose();
        Authentification an = new Authentification();
        an.setVisible(true);
    }//GEN-LAST:event_discoMouseClicked

    private void baffichreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_baffichreActionPerformed
        // TODO add your handling code here:
        firstplan.setVisible(false);
        listeouvrage.setVisible(false);
        reservationpanel.setVisible(true);
        empruntpanel.setVisible(false);
        try {
            mr.setRowCount(0);
            mr.setColumnCount(0);
            mr.addColumn("Matricule");
            mr.addColumn("Référence");
            mr.addColumn("Date");
            mr.addColumn("Nom");
            mr.addColumn("Prénom");
            pst = cr.conreserv.connexBd().prepareStatement("select * from reservation where matric=?");
            pst.setString(1, lmat.getText());
            cr.rsreserv = pst.executeQuery();
            while (cr.rsreserv.next()) {
                mr.addRow(new Object[]{
                    cr.rsreserv.getObject("matric"),
                    cr.rsreserv.getObject("refouv"),
                    cr.rsreserv.getObject("date_resv"),
                    cr.rsreserv.getObject("nom"),
                    cr.rsreserv.getObject("prenom"),});
            }
            tabreserv.setModel(mr);
        } catch (SQLException ex) {
            Logger.getLogger(EspaceAssistant.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_baffichreActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        if (JOptionPane.showConfirmDialog(this, "voulez-vous vraiment supprimer ?", "Suppression ", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
            if (tabreserv.getSelectedRowCount()==1) {
                try {
                pst = connect.connexBd().prepareStatement("delete from reservation where refouv=?");
                pst.setString(1, tabreserv.getValueAt(tabreserv.getSelectedRow(), 1).toString());
                pst.executeUpdate();
                JOptionPane.showMessageDialog(this, "La reservation a bien été supprimer", "Suppression", JOptionPane.INFORMATION_MESSAGE);

            } catch (SQLException ex) {
                Logger.getLogger(EspaceEtudiants.class.getName()).log(Level.SEVERE, null, ex);
            }
            actureserv();
        }
            }
            
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        MessageFormat header = new MessageFormat("Liste des reservations");
        MessageFormat footer = new MessageFormat("");
        try {
            tabreserv.print(JTable.PrintMode.NORMAL, header, footer);
        } catch (PrinterException ex) {
            Logger.getLogger(EspaceEtudiants.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton2ActionPerformed

    private void bdprolonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bdprolonActionPerformed
        // TODO add your handling code here:
        prolongation.setVisible(true);
        reservation.setVisible(false);
        premierplan.setVisible(false);
    }//GEN-LAST:event_bdprolonActionPerformed

    private void bproActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bproActionPerformed
        try {
            // TODO add your handling code here:
            pst = connect.connexBd().prepareStatement("insert into prolongation(matricetud,reference,nom,prenom,motif,date) values"
                    + "(?,?,?,?,?,?)");
            pst.setString(1, lmat.getText());
            pst.setString(2, tabemp.getValueAt(tabemp.getSelectedRow(), 1).toString());
            pst.setString(3, lnom.getText());
            pst.setString(4, lpnom.getText());
            pst.setString(5, motif.getText());
            SimpleDateFormat dp = new SimpleDateFormat("yyyy-MM-dd");//le m doit etre en maj
            String pd = dp.format(datp.getDate());
            pst.setString(6, pd);
            pst.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(EspaceEtudiants.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_bproActionPerformed

    private void cbsearchMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cbsearchMouseClicked
        // TODO add your handling code here:


    }//GEN-LAST:event_cbsearchMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(EspaceEtudiants.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(EspaceEtudiants.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(EspaceEtudiants.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(EspaceEtudiants.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new EspaceEtudiants().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel annee;
    private javax.swing.JLabel auteur;
    private javax.swing.JButton baffich;
    private javax.swing.JButton baffichre;
    private javax.swing.JButton bdprolon;
    private javax.swing.JButton benvoie;
    private javax.swing.JButton bexit;
    private javax.swing.JButton bpro;
    private javax.swing.JButton brech;
    private javax.swing.JButton breserver;
    private javax.swing.JComboBox cbfil;
    private javax.swing.JComboBox cbsearch;
    private com.toedter.calendar.JDateChooser datereser;
    private com.toedter.calendar.JDateChooser datp;
    private javax.swing.JLabel description;
    private javax.swing.JLabel disco;
    private javax.swing.JLabel dispo;
    private javax.swing.JLabel edition;
    private javax.swing.JPanel empruntpanel;
    private javax.swing.JLabel filiere;
    private javax.swing.JPanel firstplan;
    private javax.swing.JPanel info;
    private javax.swing.JLabel intitule;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jadescrip;
    private javax.swing.JTextArea jadesrip;
    private javax.swing.JTextField jtmat;
    private javax.swing.JTextField jtnom;
    private javax.swing.JTextField jtpnom;
    private javax.swing.JTextField jtrech;
    private javax.swing.JLabel lanne;
    private javax.swing.JLabel lauteur;
    private javax.swing.JLabel ledit;
    private javax.swing.JLabel lfiliere;
    private javax.swing.JLabel lfond;
    private javax.swing.JLabel lintitule;
    private javax.swing.JPanel listeouvrage;
    public static javax.swing.JLabel lmat;
    public static javax.swing.JLabel lnom;
    private javax.swing.JLabel lphoto;
    public static javax.swing.JLabel lpnom;
    private javax.swing.JLabel lref;
    private javax.swing.JLabel ltit;
    private javax.swing.JLabel matricule;
    private javax.swing.JTextArea motif;
    private javax.swing.JLabel nom;
    private javax.swing.JPanel panelphoto;
    private javax.swing.JLabel pnom;
    private javax.swing.JPanel premierplan;
    private javax.swing.JPanel prolongation;
    private javax.swing.JPanel recherche;
    private javax.swing.JPanel reservation;
    private javax.swing.JPanel reservationpanel;
    private javax.swing.JLabel reserveffec;
    private javax.swing.JTable tabemp;
    private javax.swing.JTable tabouvrech;
    private javax.swing.JTable tabreserv;
    // End of variables declaration//GEN-END:variables

    private void setIcon() {
        setIconImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("BIBLIO.png")));
    }
}
