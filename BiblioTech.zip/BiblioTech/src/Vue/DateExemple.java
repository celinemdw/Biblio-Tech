/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Vue;
import java.util.Date;
import java.text.SimpleDateFormat;
/**
 *
 * @author ASUS VIVOBOOK
 */



public class DateExemple{
   public static void main(String args[]){
     
   SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
     try {
         Date dateAvant = sdf.parse("02/25/2012");
         Date dateApres = sdf.parse("03/31/2012");
         long diff = dateApres.getTime() - dateAvant.getTime();
         float res = (diff / (1000*60*60*24));
         System.out.println("Nombre de jours entre les deux dates est: "+res);
     } catch (Exception e) {
         e.printStackTrace();
     }
   }
}