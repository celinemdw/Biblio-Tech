/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Vue;

import Modele.ConnectBdd;
import Modele.ConnectEmprunt;
import Modele.ConnectOuv;
import Modele.ConnectPenal;
import Modele.ConnectReservation;
import Modele.ConnexEtudiant;
import Modele.ConnexProlong;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.print.PrinterException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.MessageFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author ASUS VIVOBOOK
 */
public class EspaceAssistant extends javax.swing.JFrame {

    /**
     * Creates new form GestionOuvrageAssistant
     */
    ConnectBdd connect = new ConnectBdd();
    PreparedStatement pst;
    DefaultTableModel mo = new DefaultTableModel();
    DefaultTableModel mr = new DefaultTableModel();
    DefaultTableModel memp = new DefaultTableModel();
    DefaultTableModel mp = new DefaultTableModel();
    DefaultTableModel mop = new DefaultTableModel();
    ResultSet rs, rs1;
    Statement stat, stat1;
    ConnectOuv co = new ConnectOuv();
    ConnectReservation cr = new ConnectReservation();
    ConnectEmprunt cemp = new ConnectEmprunt();
    ConnexProlong cp = new ConnexProlong();
    ConnectPenal cop = new ConnectPenal();
   

    public EspaceAssistant() {
        initComponents();
        setLocationRelativeTo(this);
        setIcon();
        setTitle("ESPACE ASSISTANT");
        bordure.setEditable(false);
        reservationpanel.setVisible(false);
        emprunt.setVisible(false);
        jPanel1.setVisible(false);
        penalite.setVisible(false);
        DateFormat format = new SimpleDateFormat("dd/MM/yyyy");
        Date date = new Date();
       vc.setText(format.format(date));
      
        //table des penalité
        try {
            mop.setRowCount(0);
            mop.setColumnCount(0);
            mop.addColumn("Matricule");
            mop.addColumn("Référence");
            mop.addColumn("Nom");
            mop.addColumn("Prénom");
            mop.addColumn("Date Prévu de retour");
            mop.addColumn("Nombre de Jour");
            pst = cop.cop.connexBd().prepareStatement("select * from penalite");
            cop.rsp = pst.executeQuery();
            while (cop.rsp.next()) {
                mp.addRow(new Object[]{
                    cop.rsp.getObject("matricetud"),
                    cop.rsp.getObject("reference"),
                    cop.rsp.getObject("motif"),
                    cop.rsp.getObject("nom"),
                    cop.rsp.getObject("prenom"),
                    cop.rsp.getObject("date_prev"),
                    cop.rsp.getObject("date")
                });
            }
            tabpenal.setModel(mop);
        } catch (SQLException ex) {
            Logger.getLogger(EspaceAssistant.class.getName()).log(Level.SEVERE, null, ex);
        }

        //table prolongation
        try {
            mp.setRowCount(0);
            mp.setColumnCount(0);
            mp.addColumn("Matricule");
            mp.addColumn("Référence");
            mp.addColumn("Motif");
            mp.addColumn("Nom");
            mp.addColumn("Prénom");
            mp.addColumn("Date");
            pst = cp.cop.connexBd().prepareStatement("select * from prolongation");
            cp.rspro = pst.executeQuery();
            while (cp.rspro.next()) {
                mp.addRow(new Object[]{
                    cp.rspro.getObject("matricetud"),
                    cp.rspro.getObject("reference"),
                    cp.rspro.getObject("motif"),
                    cp.rspro.getObject("nom"),
                    cp.rspro.getObject("prenom"),
                    cp.rspro.getObject("date")
                });
            }
            tabrpol.setModel(mp);
        } catch (SQLException ex) {
            Logger.getLogger(EspaceAssistant.class.getName()).log(Level.SEVERE, null, ex);
        }
        //table emprunt
        try {
            memp.setRowCount(0);
            memp.setColumnCount(0);
            memp.addColumn("Matricule");
            memp.addColumn("Référence");
            memp.addColumn("Date");
            memp.addColumn("Dte retour");
            memp.addColumn("Nom");
            memp.addColumn("Prénom");
            pst = cemp.coemp.connexBd().prepareStatement("select * from emprunt");
            cemp.rsemp = pst.executeQuery();
            while (cemp.rsemp.next()) {
                memp.addRow(new Object[]{
                    cemp.rsemp.getObject("matricule"),
                    cemp.rsemp.getObject("ref"),
                    cemp.rsemp.getObject("date_empr"),
                    cemp.rsemp.getObject("date_ret"),
                    cemp.rsemp.getObject("nom"),
                    cemp.rsemp.getObject("prenom")
                });
            }
            tabemp.setModel(memp);
        } catch (SQLException ex) {
            Logger.getLogger(EspaceAssistant.class.getName()).log(Level.SEVERE, null, ex);
        }
        //table ouvrages
        mo.setRowCount(0);
        mo.setColumnCount(0);
        try {
            mo.setRowCount(0);
            mo.setColumnCount(0);

            mo.addColumn("Référence");
            mo.addColumn("Intitulé");
            mo.addColumn("Auteur");
            mo.addColumn("Edition");
            mo.addColumn("Année d'edition");
            mo.addColumn("Photo");
            mo.addColumn("Path");
            mo.addColumn("Spécialité");
            mo.addColumn("Description");
            mo.addColumn("Quantité");
            pst = co.cono.connexBd().prepareStatement("select * from ouvrages order by intitule asc");
            co.rso = pst.executeQuery();
            while (co.rso.next()) {
                mo.addRow(new Object[]{
                    co.rso.getObject("reference"),
                    co.rso.getObject("intitule"),
                    co.rso.getObject("auteur"),
                    co.rso.getObject("edition"),
                    co.rso.getObject("annee_edi"),
                    co.rso.getBlob("photo"),
                    co.rso.getObject("path"),
                    co.rso.getObject("categorie"),
                    co.rso.getObject("description"),
                    co.rso.getObject("quantite")
                });
            }
            tabasouv.setModel(mo);
        } catch (SQLException ex) {
            Logger.getLogger(EspaceAssistant.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void actupro() {
        try {
            mp.setRowCount(0);
            mp.setColumnCount(0);
            mp.addColumn("Matricule");
            mp.addColumn("Référence");

            mp.addColumn("Motif");
            mp.addColumn("Nom");
            mp.addColumn("Prénom");
            mp.addColumn("Date");
            pst = cp.cop.connexBd().prepareStatement("select * from prolongation");
            cp.rspro = pst.executeQuery();
            while (cp.rspro.next()) {
                mp.addRow(new Object[]{
                    cp.rspro.getObject("matricetud"),
                    cp.rspro.getObject("reference"),
                    cp.rspro.getObject("motif"),
                    cp.rspro.getObject("nom"),
                    cp.rspro.getObject("prenom"),
                    cp.rspro.getObject("date")
                });
            }
            tabrpol.setModel(mp);
        } catch (SQLException ex) {
            Logger.getLogger(EspaceAssistant.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void actureserv() {
        try {
            mr.setRowCount(0);
            mr.setColumnCount(0);
            mr.addColumn("Matricule");
            mr.addColumn("Référence");
            mr.addColumn("Date");
            mr.addColumn("Nom");
            mr.addColumn("Prénom");
            pst = cr.conreserv.connexBd().prepareStatement("select * from reservation");
            cr.rsreserv = pst.executeQuery();
            while (cr.rsreserv.next()) {
                mr.addRow(new Object[]{
                    cr.rsreserv.getObject("matric"),
                    cr.rsreserv.getObject("refouv"),
                    cr.rsreserv.getObject("date_resv"),
                    cr.rsreserv.getObject("nom"),
                    cr.rsreserv.getObject("prenom"),});
            }
            tabreserv.setModel(mr);
        } catch (SQLException ex) {
            Logger.getLogger(EspaceAssistant.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void actuemprunt() {
        try {
            memp.setRowCount(0);
            memp.setColumnCount(0);
            memp.addColumn("Matricule");
            memp.addColumn("Référence");
            memp.addColumn("Date");
            memp.addColumn("Date retour");
            memp.addColumn("Nom");
            memp.addColumn("Prénom");
            pst = cemp.coemp.connexBd().prepareStatement("select * from emprunt");
            cemp.rsemp = pst.executeQuery();
            while (cemp.rsemp.next()) {
                memp.addRow(new Object[]{
                    cemp.rsemp.getObject("matricule"),
                    cemp.rsemp.getObject("ref"),
                    cemp.rsemp.getObject("date_empr"),
                    cemp.rsemp.getObject("date_ret"),
                    cemp.rsemp.getObject("nom"),
                    cemp.rsemp.getObject("prenom")
                });
            }
            tabemp.setModel(memp);
        } catch (SQLException ex) {
            Logger.getLogger(EspaceAssistant.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void affichageouv(int ls) {
        refg.setText(tabasouv.getValueAt(ls, 0).toString());
        jtintit.setText(tabasouv.getValueAt(ls, 1).toString());
        jtaut.setText(tabasouv.getValueAt(ls, 2).toString());
        jtedit.setText(tabasouv.getValueAt(ls, 3).toString());
        jpath.setText(tabasouv.getValueAt(ls, 6).toString());
        cbsp.setSelectedItem(tabasouv.getValueAt(ls, 7));
        jadescrip.setText(tabasouv.getValueAt(ls, 8).toString());
        jann.setYear(Integer.parseInt(tabasouv.getValueAt(ls, 4).toString()));//ca marche pas
        //recuperer la photo de la jtable
        try {

            pst = connect.connexBd().prepareStatement("select photo from ouvrages where reference=?");
            pst.setString(1, tabasouv.getValueAt(ls, 0).toString());
            rs = pst.executeQuery();
            while (rs.next()) {
                byte tabimg[] = rs.getBytes("photo");
                ImageIcon photo = new ImageIcon(tabimg);
                Image photorec = photo.getImage().getScaledInstance(lphoto.getWidth(), lphoto.getHeight(), Image.SCALE_SMOOTH);
                ImageIcon photorecf = new ImageIcon(photorec);
                lphoto.setIcon(photorecf);
            }

        } catch (SQLException ex) {
            Logger.getLogger(EspaceAdministrateur.class.getName()).log(Level.SEVERE, null, ex);
        }
        jtquant.setText(tabasouv.getValueAt(ls, 9).toString());

    }

    public void reinitialisationouv() {
        refg.setText("");
        jtintit.setText(null);
        jtaut.setText(null);
        jann.setYear(2021);
        jtedit.setText(null);
        cbsp.setSelectedItem(null);
        lphoto.setIcon(null);
        jpath.setText(null);
        jadescrip.setText(null);
        jtquant.setText(null);
    }

    public void actualisationouv() {
        mo.setRowCount(0);
        mo.setColumnCount(0);
        try {
            mo.setRowCount(0);
            mo.setColumnCount(0);

            mo.addColumn("Référence");
            mo.addColumn("Intitulé");
            mo.addColumn("Auteur");
            mo.addColumn("Edition");
            mo.addColumn("Année d'edition");
            mo.addColumn("Photo");
            mo.addColumn("Path");
            mo.addColumn("Spécialité");
            mo.addColumn("Description");
            mo.addColumn("Quantite");
            pst = co.cono.connexBd().prepareStatement("select * from ouvrages");
            co.rso = pst.executeQuery();
            while (co.rso.next()) {
                mo.addRow(new Object[]{
                    co.rso.getObject("reference"),
                    co.rso.getObject("intitule"),
                    co.rso.getObject("auteur"),
                    co.rso.getObject("edition"),
                    co.rso.getObject("annee_edi"),
                    co.rso.getBlob("photo"),
                    co.rso.getObject("path"),
                    co.rso.getObject("categorie"),
                    co.rso.getObject("description"),
                    co.rso.getObject("quantite")

                });
            }
            tabasouv.setModel(mo);
        } catch (SQLException ex) {
            Logger.getLogger(EspaceAssistant.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        penalite = new javax.swing.JPanel();
        jScrollPane6 = new javax.swing.JScrollPane();
        tabpenal = new javax.swing.JTable();
        jButton2 = new javax.swing.JButton();
        jLabel11 = new javax.swing.JLabel();
        ajoutouinfo = new javax.swing.JPanel();
        description = new javax.swing.JLabel();
        intitul = new javax.swing.JLabel();
        auteur = new javax.swing.JLabel();
        edition = new javax.swing.JLabel();
        year = new javax.swing.JLabel();
        specialité = new javax.swing.JLabel();
        reference = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jadescrip = new javax.swing.JTextArea();
        pimage = new javax.swing.JPanel();
        lphoto = new javax.swing.JLabel();
        bphoto = new javax.swing.JButton();
        jtintit = new javax.swing.JTextField();
        refg = new javax.swing.JLabel();
        jtaut = new javax.swing.JTextField();
        jtedit = new javax.swing.JTextField();
        jann = new com.toedter.calendar.JYearChooser();
        cbsp = new javax.swing.JComboBox();
        jLabel3 = new javax.swing.JLabel();
        jtquant = new javax.swing.JTextField();
        bajout = new javax.swing.JButton();
        liste = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tabasouv = new javax.swing.JTable();
        lnom = new javax.swing.JLabel();
        lpnom = new javax.swing.JLabel();
        baffichlist = new javax.swing.JButton();
        blistreserv = new javax.swing.JButton();
        bquit = new javax.swing.JButton();
        cbsearch = new javax.swing.JComboBox();
        cbfiliereas = new javax.swing.JComboBox();
        bordure = new javax.swing.JTextField();
        jtsearch = new javax.swing.JTextField();
        bsearch = new javax.swing.JButton();
        titre = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane5 = new javax.swing.JScrollPane();
        tabrpol = new javax.swing.JTable();
        emprunt = new javax.swing.JPanel();
        jScrollPane4 = new javax.swing.JScrollPane();
        tabemp = new javax.swing.JTable();
        bsuppemp = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        baddprolong = new javax.swing.JButton();
        jLabel9 = new javax.swing.JLabel();
        bsearchEmp = new javax.swing.JButton();
        jtsemp = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        reservationpanel = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        tabreserv = new javax.swing.JTable();
        bval = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jdret = new com.toedter.calendar.JDateChooser();
        jLabel8 = new javax.swing.JLabel();
        bsearchreserv = new javax.swing.JButton();
        jtsre = new javax.swing.JTextField();
        icone = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        disco = new javax.swing.JButton();
        bemprunt = new javax.swing.JButton();
        bprolong = new javax.swing.JButton();
        bpenal = new javax.swing.JButton();
        baffich = new javax.swing.JButton();
        vc = new javax.swing.JLabel();
        lfond = new javax.swing.JLabel();
        jpath = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        penalite.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED), "Liste des etudiant pénalisés", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Calibri", 3, 20), new java.awt.Color(0, 0, 204))); // NOI18N
        penalite.setOpaque(false);

        tabpenal.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        jScrollPane6.setViewportView(tabpenal);

        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/remarche.png"))); // NOI18N

        jLabel11.setFont(new java.awt.Font("Calibri", 3, 20)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(0, 0, 204));
        jLabel11.setText("Pour supprimer la pénalité :");

        javax.swing.GroupLayout penaliteLayout = new javax.swing.GroupLayout(penalite);
        penalite.setLayout(penaliteLayout);
        penaliteLayout.setHorizontalGroup(
            penaliteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(penaliteLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(penaliteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(penaliteLayout.createSequentialGroup()
                        .addGap(0, 261, Short.MAX_VALUE)
                        .addComponent(jLabel11)
                        .addGap(18, 18, 18)
                        .addComponent(jButton2))
                    .addComponent(jScrollPane6))
                .addContainerGap())
        );
        penaliteLayout.setVerticalGroup(
            penaliteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(penaliteLayout.createSequentialGroup()
                .addGap(50, 50, 50)
                .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(37, 37, 37)
                .addGroup(penaliteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jButton2)
                    .addComponent(jLabel11))
                .addContainerGap(111, Short.MAX_VALUE))
        );

        getContentPane().add(penalite, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 180, 620, 670));

        ajoutouinfo.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED), "Ajouter un ouvrage", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Calibri", 3, 24), new java.awt.Color(0, 0, 204))); // NOI18N
        ajoutouinfo.setOpaque(false);
        ajoutouinfo.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        description.setFont(new java.awt.Font("Calibri", 3, 20)); // NOI18N
        description.setForeground(new java.awt.Color(0, 0, 204));
        description.setText("Description :");
        ajoutouinfo.add(description, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 340, -1, -1));

        intitul.setFont(new java.awt.Font("Calibri", 3, 20)); // NOI18N
        intitul.setForeground(new java.awt.Color(0, 0, 204));
        intitul.setText("Intitulé :");
        ajoutouinfo.add(intitul, new org.netbeans.lib.awtextra.AbsoluteConstraints(22, 84, -1, -1));

        auteur.setFont(new java.awt.Font("Calibri", 3, 20)); // NOI18N
        auteur.setForeground(new java.awt.Color(0, 0, 204));
        auteur.setText("Auteur :");
        ajoutouinfo.add(auteur, new org.netbeans.lib.awtextra.AbsoluteConstraints(22, 122, -1, -1));

        edition.setFont(new java.awt.Font("Calibri", 3, 20)); // NOI18N
        edition.setForeground(new java.awt.Color(0, 0, 204));
        edition.setText("Edition :");
        ajoutouinfo.add(edition, new org.netbeans.lib.awtextra.AbsoluteConstraints(22, 160, -1, -1));

        year.setFont(new java.awt.Font("Calibri", 3, 20)); // NOI18N
        year.setForeground(new java.awt.Color(0, 0, 204));
        year.setText("Année :");
        ajoutouinfo.add(year, new org.netbeans.lib.awtextra.AbsoluteConstraints(22, 198, -1, -1));

        specialité.setFont(new java.awt.Font("Calibri", 3, 20)); // NOI18N
        specialité.setForeground(new java.awt.Color(0, 0, 204));
        specialité.setText("Spécialité :");
        ajoutouinfo.add(specialité, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 240, -1, -1));

        reference.setFont(new java.awt.Font("Calibri", 3, 20)); // NOI18N
        reference.setForeground(new java.awt.Color(0, 0, 204));
        reference.setText("Réference :");
        ajoutouinfo.add(reference, new org.netbeans.lib.awtextra.AbsoluteConstraints(22, 48, -1, -1));

        jadescrip.setColumns(20);
        jadescrip.setRows(5);
        jScrollPane1.setViewportView(jadescrip);

        ajoutouinfo.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 350, 340, -1));

        pimage.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        pimage.setOpaque(false);

        javax.swing.GroupLayout pimageLayout = new javax.swing.GroupLayout(pimage);
        pimage.setLayout(pimageLayout);
        pimageLayout.setHorizontalGroup(
            pimageLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pimageLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lphoto, javax.swing.GroupLayout.DEFAULT_SIZE, 134, Short.MAX_VALUE)
                .addContainerGap())
        );
        pimageLayout.setVerticalGroup(
            pimageLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pimageLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lphoto, javax.swing.GroupLayout.DEFAULT_SIZE, 152, Short.MAX_VALUE)
                .addContainerGap())
        );

        ajoutouinfo.add(pimage, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 40, 170, 190));

        bphoto.setFont(new java.awt.Font("Calibri", 3, 16)); // NOI18N
        bphoto.setForeground(new java.awt.Color(0, 0, 204));
        bphoto.setText("Charger la photo");
        bphoto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bphotoActionPerformed(evt);
            }
        });
        ajoutouinfo.add(bphoto, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 240, 170, -1));
        ajoutouinfo.add(jtintit, new org.netbeans.lib.awtextra.AbsoluteConstraints(133, 81, 210, -1));

        refg.setFont(new java.awt.Font("Calibri", 3, 20)); // NOI18N
        refg.setForeground(new java.awt.Color(0, 0, 204));
        ajoutouinfo.add(refg, new org.netbeans.lib.awtextra.AbsoluteConstraints(133, 48, 210, 30));
        ajoutouinfo.add(jtaut, new org.netbeans.lib.awtextra.AbsoluteConstraints(133, 119, 210, -1));
        ajoutouinfo.add(jtedit, new org.netbeans.lib.awtextra.AbsoluteConstraints(133, 157, 210, -1));
        ajoutouinfo.add(jann, new org.netbeans.lib.awtextra.AbsoluteConstraints(133, 198, 210, -1));

        cbsp.setFont(new java.awt.Font("Calibri", 1, 20)); // NOI18N
        cbsp.setForeground(new java.awt.Color(0, 0, 204));
        cbsp.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Architecture", "Automatique", "Chimie", "Eléctronique", "Géologie", "Informatique", "Mathematique", "Mécanique", "Médecine", "Physique", "Réseaux", "Statistique" }));
        cbsp.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                cbspFocusLost(evt);
            }
        });
        ajoutouinfo.add(cbsp, new org.netbeans.lib.awtextra.AbsoluteConstraints(133, 242, 210, -1));

        jLabel3.setFont(new java.awt.Font("Calibri", 3, 20)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 0, 204));
        jLabel3.setText("Quantité :");
        ajoutouinfo.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 290, -1, -1));
        ajoutouinfo.add(jtquant, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 290, 210, -1));

        getContentPane().add(ajoutouinfo, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 140, 620, 460));

        bajout.setFont(new java.awt.Font("Calibri", 3, 18)); // NOI18N
        bajout.setForeground(new java.awt.Color(0, 0, 204));
        bajout.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/addbok.png"))); // NOI18N
        bajout.setText("Ajouter");
        bajout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bajoutActionPerformed(evt);
            }
        });
        getContentPane().add(bajout, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 450, 150, 40));

        liste.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED), "Listes des ouvrages", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Calibri", 3, 24), new java.awt.Color(0, 0, 204))); // NOI18N
        liste.setOpaque(false);

        tabasouv.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        tabasouv.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tabasouvMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(tabasouv);

        javax.swing.GroupLayout listeLayout = new javax.swing.GroupLayout(liste);
        liste.setLayout(listeLayout);
        listeLayout.setHorizontalGroup(
            listeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(listeLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 576, Short.MAX_VALUE)
                .addContainerGap())
        );
        listeLayout.setVerticalGroup(
            listeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(listeLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 199, Short.MAX_VALUE)
                .addContainerGap())
        );

        getContentPane().add(liste, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 610, 620, 270));

        lnom.setFont(new java.awt.Font("Calibri", 3, 24)); // NOI18N
        lnom.setForeground(new java.awt.Color(0, 0, 204));
        getContentPane().add(lnom, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 250, -1, -1));

        lpnom.setFont(new java.awt.Font("Calibri", 3, 24)); // NOI18N
        lpnom.setForeground(new java.awt.Color(0, 0, 204));
        getContentPane().add(lpnom, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 280, -1, -1));

        baffichlist.setFont(new java.awt.Font("Calibri", 3, 18)); // NOI18N
        baffichlist.setForeground(new java.awt.Color(0, 0, 204));
        baffichlist.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Afficher.png"))); // NOI18N
        baffichlist.setText("  Liste    ");
        baffichlist.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                baffichlistActionPerformed(evt);
            }
        });
        getContentPane().add(baffichlist, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 700, 150, 30));

        blistreserv.setFont(new java.awt.Font("Calibri", 3, 18)); // NOI18N
        blistreserv.setForeground(new java.awt.Color(0, 0, 204));
        blistreserv.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/reserver.png"))); // NOI18N
        blistreserv.setText("Reservation");
        blistreserv.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                blistreservActionPerformed(evt);
            }
        });
        getContentPane().add(blistreserv, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 500, 150, 40));

        bquit.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/exit.png"))); // NOI18N
        bquit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bquitActionPerformed(evt);
            }
        });
        getContentPane().add(bquit, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 820, -1, 80));

        cbsearch.setFont(new java.awt.Font("Calibri", 3, 20)); // NOI18N
        cbsearch.setForeground(new java.awt.Color(0, 0, 204));
        cbsearch.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Filiere", "Intitule" }));
        cbsearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbsearchActionPerformed(evt);
            }
        });
        getContentPane().add(cbsearch, new org.netbeans.lib.awtextra.AbsoluteConstraints(1110, 10, 150, 30));

        cbfiliereas.setFont(new java.awt.Font("Calibri", 3, 20)); // NOI18N
        cbfiliereas.setForeground(new java.awt.Color(0, 0, 204));
        cbfiliereas.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Architecture", "Automatique", "Chimie", "Eléctronique", "Géologie", "Informatique", "Mathematique", "Mécanique", "Médecine", "Physique", "Réseaux", "Statistique" }));
        getContentPane().add(cbfiliereas, new org.netbeans.lib.awtextra.AbsoluteConstraints(1110, 50, 150, 30));

        bordure.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bordureActionPerformed(evt);
            }
        });
        getContentPane().add(bordure, new org.netbeans.lib.awtextra.AbsoluteConstraints(1100, -10, 10, 140));

        jtsearch.setFont(new java.awt.Font("Calibri", 3, 16)); // NOI18N
        jtsearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jtsearchActionPerformed(evt);
            }
        });
        getContentPane().add(jtsearch, new org.netbeans.lib.awtextra.AbsoluteConstraints(1110, 90, 150, 30));

        bsearch.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/search.png"))); // NOI18N
        bsearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bsearchActionPerformed(evt);
            }
        });
        getContentPane().add(bsearch, new org.netbeans.lib.awtextra.AbsoluteConstraints(1270, 90, -1, -1));

        titre.setFont(new java.awt.Font("Calibri", 3, 48)); // NOI18N
        titre.setForeground(new java.awt.Color(255, 255, 255));
        titre.setText("ESPACE ASSISTANT");
        getContentPane().add(titre, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 30, -1, -1));

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED), "Les Demandes de prolongations", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Calibri", 3, 20), new java.awt.Color(0, 0, 204))); // NOI18N
        jPanel1.setToolTipText("");
        jPanel1.setOpaque(false);

        tabrpol.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        jScrollPane5.setViewportView(tabrpol);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(63, Short.MAX_VALUE)
                .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 348, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(134, 134, 134))
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(840, 190, 480, 580));

        emprunt.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED), "Emprunts", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Calibri", 3, 24), new java.awt.Color(0, 0, 204))); // NOI18N
        emprunt.setOpaque(false);
        emprunt.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        tabemp.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        jScrollPane4.setViewportView(tabemp);

        emprunt.add(jScrollPane4, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 80, 410, 440));

        bsuppemp.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8_delete_26px.png"))); // NOI18N
        bsuppemp.setOpaque(false);
        bsuppemp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bsuppempActionPerformed(evt);
            }
        });
        emprunt.add(bsuppemp, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 560, -1, -1));

        jLabel6.setFont(new java.awt.Font("Calibri", 3, 18)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(0, 0, 204));
        jLabel6.setText("Une fois que l'etudiant aura rendu l'ouvrage emprunter");
        emprunt.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 530, -1, -1));

        jLabel7.setFont(new java.awt.Font("Calibri", 3, 18)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(0, 0, 204));
        jLabel7.setText("Vous pouvez supprimer l'emprunt par ici");
        emprunt.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 560, -1, -1));

        baddprolong.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/prolongation.png"))); // NOI18N
        baddprolong.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                baddprolongActionPerformed(evt);
            }
        });
        emprunt.add(baddprolong, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 610, -1, -1));

        jLabel9.setFont(new java.awt.Font("Calibri", 3, 18)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(0, 0, 204));
        jLabel9.setText("Pour accepter la prolongation :");
        emprunt.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 590, -1, -1));

        bsearchEmp.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/search.png"))); // NOI18N
        bsearchEmp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bsearchEmpActionPerformed(evt);
            }
        });
        emprunt.add(bsearchEmp, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 40, -1, -1));
        emprunt.add(jtsemp, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 40, 140, 30));

        jLabel10.setFont(new java.awt.Font("Calibri", 3, 18)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(0, 0, 204));
        jLabel10.setText("Si l'etudiant n'a pas rendu l'ouvrage emprunté :");
        emprunt.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 650, -1, -1));

        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/penal.png"))); // NOI18N
        emprunt.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 670, -1, -1));

        getContentPane().add(emprunt, new org.netbeans.lib.awtextra.AbsoluteConstraints(840, 170, 480, 710));

        reservationpanel.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED), "Listes des reservations", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Calibri", 1, 20), new java.awt.Color(0, 0, 204))); // NOI18N
        reservationpanel.setOpaque(false);
        reservationpanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        tabreserv.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        jScrollPane3.setViewportView(tabreserv);

        reservationpanel.add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 90, 407, -1));

        bval.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8_checkmark_26px.png"))); // NOI18N
        bval.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bvalActionPerformed(evt);
            }
        });
        reservationpanel.add(bval, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 570, -1, -1));

        jLabel4.setFont(new java.awt.Font("Calibri", 1, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 0, 204));
        jLabel4.setText("Après que l'etudiant récupère les ouvrages qu'il avait réservés");
        reservationpanel.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 550, -1, 20));

        jLabel5.setFont(new java.awt.Font("Calibri", 1, 18)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(0, 0, 204));
        jLabel5.setText("Cliquez ici pour valider son emprunt.");
        reservationpanel.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 580, -1, -1));
        reservationpanel.add(jdret, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 510, 180, -1));

        jLabel8.setFont(new java.awt.Font("Calibri", 3, 18)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(0, 0, 204));
        jLabel8.setText("L'etudiant doit rendre l'ouvrage le :");
        reservationpanel.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 510, -1, -1));

        bsearchreserv.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/search.png"))); // NOI18N
        bsearchreserv.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bsearchreservActionPerformed(evt);
            }
        });
        reservationpanel.add(bsearchreserv, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 40, -1, -1));
        reservationpanel.add(jtsre, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 40, 130, 30));

        getContentPane().add(reservationpanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(840, 180, 480, 630));

        icone.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/OPEN-BOOK2.png"))); // NOI18N
        getContentPane().add(icone, new org.netbeans.lib.awtextra.AbsoluteConstraints(860, 250, -1, -1));

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 204));
        jLabel1.setText("Bienvenu(e)   ");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 220, -1, -1));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8_user_menu_male_64px.png"))); // NOI18N
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 150, -1, -1));

        disco.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/se decconecter.png"))); // NOI18N
        disco.setOpaque(false);
        disco.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                discoActionPerformed(evt);
            }
        });
        getContentPane().add(disco, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 740, 150, 40));

        bemprunt.setFont(new java.awt.Font("Calibri", 3, 20)); // NOI18N
        bemprunt.setForeground(new java.awt.Color(0, 0, 204));
        bemprunt.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/emprunt.png"))); // NOI18N
        bemprunt.setText("Emprunt");
        bemprunt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bempruntActionPerformed(evt);
            }
        });
        getContentPane().add(bemprunt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 550, 150, -1));

        bprolong.setFont(new java.awt.Font("Calibri", 3, 16)); // NOI18N
        bprolong.setForeground(new java.awt.Color(0, 0, 204));
        bprolong.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/prolongation.png"))); // NOI18N
        bprolong.setText("Prolongation");
        bprolong.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bprolongActionPerformed(evt);
            }
        });
        getContentPane().add(bprolong, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 650, 150, 40));

        bpenal.setFont(new java.awt.Font("Calibri", 3, 20)); // NOI18N
        bpenal.setForeground(new java.awt.Color(0, 0, 204));
        bpenal.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/penal.png"))); // NOI18N
        bpenal.setText("Pénalité");
        bpenal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bpenalActionPerformed(evt);
            }
        });
        getContentPane().add(bpenal, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 599, 150, 40));

        baffich.setFont(new java.awt.Font("Calibri", 3, 20)); // NOI18N
        baffich.setForeground(new java.awt.Color(0, 0, 204));
        baffich.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/lis.png"))); // NOI18N
        baffich.setText("Affichage");
        baffich.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                baffichActionPerformed(evt);
            }
        });
        getContentPane().add(baffich, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 400, 150, -1));

        vc.setFont(new java.awt.Font("Calibri", 3, 24)); // NOI18N
        vc.setForeground(new java.awt.Color(255, 255, 255));
        getContentPane().add(vc, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 90, 360, 40));

        lfond.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/espaceassistant.png"))); // NOI18N
        getContentPane().add(lfond, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));
        getContentPane().add(jpath, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 280, 170, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void baffichlistActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_baffichlistActionPerformed
        // TODO add your handling code here:
        MessageFormat header = new MessageFormat("Liste des ouvrages");
        MessageFormat footer = new MessageFormat("");
        try {
            tabasouv.print(JTable.PrintMode.NORMAL, header, footer);
        } catch (PrinterException ex) {
            Logger.getLogger(EspaceAssistant.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_baffichlistActionPerformed

    private void bajoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bajoutActionPerformed

        try {

            pst = connect.connexBd().prepareStatement("insert into ouvrages(reference,intitule,auteur,annee_edi,"
                    + "edition,photo,path,categorie,description,quantite) values"
                    + "(?,?,?,?,?,?,?,?,?,?)");
            pst.setString(1, refg.getText());
            pst.setString(2, jtintit.getText());
            pst.setString(3, jtaut.getText());
            pst.setObject(4, jann.getYear());
            pst.setString(5, jtedit.getText());
            // pour ajouter la photo
            try {
                //1-lire la photo
                InputStream rimg = new FileInputStream(jpath.getText());
                //2-mettre la photo
                pst.setBlob(6, rimg);
            } catch (FileNotFoundException ex) {
                Logger.getLogger(EspaceAssistant.class.getName()).log(Level.SEVERE, null, ex);
            }
            pst.setString(7, jpath.getText());
            pst.setString(8, cbsp.getSelectedItem().toString());
            pst.setString(9, jadescrip.getText());
            pst.setString(9, jadescrip.getText());
            pst.setString(10, jtquant.getText());
            // envoyer la requete
            pst.executeUpdate();
            JOptionPane.showMessageDialog(this, "Ouvrage ajouté");
        } catch (SQLException ex) {
            Logger.getLogger(EspaceAssistant.class.getName()).log(Level.SEVERE, null, ex);
        }
        reinitialisationouv();
        actualisationouv();


    }//GEN-LAST:event_bajoutActionPerformed

    private void tabasouvMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tabasouvMouseClicked
        // TODO add your handling code here:
        affichageouv(tabasouv.getSelectedRow());
    }//GEN-LAST:event_tabasouvMouseClicked

    private void bphotoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bphotoActionPerformed
        // TODO add your handling code here:
        JFileChooser fileChooser = new JFileChooser();
        //préciser le dossier ou se trouvent les images
        fileChooser.setCurrentDirectory(new File("C:\\Users\\ASUS VIVOBOOK\\Desktop\\PFC\\ouvrages"));
        FileNameExtensionFilter filter = new FileNameExtensionFilter("Image", "jpg", "png", "gif");
        fileChooser.addChoosableFileFilter(filter);//why
        int result = fileChooser.showOpenDialog(null);//why
        if (result == JFileChooser.APPROVE_OPTION) {

            File fichierselectionne = fileChooser.getSelectedFile();
            String path = fichierselectionne.getAbsolutePath();
            ImageIcon img = new ImageIcon(path);
            Image imgrec = img.getImage();
            Image nimage = imgrec.getScaledInstance(lphoto.getWidth(),
                    lphoto.getHeight(), Image.SCALE_SMOOTH);
            ImageIcon imgfinal = new ImageIcon(nimage);

            lphoto.setIcon(imgfinal);

            jpath.setText(path);
        } else if (result == JFileChooser.CANCEL_OPTION) {
            JOptionPane.showMessageDialog(null, "Aucun choix effectué");
        }
    }//GEN-LAST:event_bphotoActionPerformed

    private void cbspFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_cbspFocusLost
        // TODO add your handling code here:
        refg.setText((cbsp.getSelectedItem().toString().substring(0, 3) + jtintit.getText().substring(0, 2)).toUpperCase()
                + jann.getYear());
    }//GEN-LAST:event_cbspFocusLost

    private void bsearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bsearchActionPerformed
        // TODO add your handling code here:
        if (cbsearch.getSelectedItem().equals("Filiere")) {
            mo.setRowCount(0);
            try {
                pst = connect.connexBd().prepareStatement("select * from ouvrages where categorie=?");
                pst.setString(1, cbfiliereas.getSelectedItem().toString());
                rs = pst.executeQuery();
                while (rs.next()) {
                    mo.addRow(new Object[]{
                        rs.getObject("reference"),
                        rs.getObject("intitule"),
                        rs.getObject("auteur"),
                        rs.getObject("edition"),
                        rs.getObject("annee_edi"),
                        rs.getBlob("photo"),
                        rs.getObject("Path"),
                        rs.getObject("categorie"),
                        rs.getObject("description"),
                        rs.getObject("quantite")});
                }
                tabasouv.setModel(mo);
                if (mo.getRowCount() == 0) {
                    JOptionPane.showMessageDialog(this, "l'ouvrage n'existe pas");
                } else {
                    affichageouv(0);
                }
            } catch (SQLException ex) {
                Logger.getLogger(EspaceEtudiants.class.getName()).log(Level.SEVERE, null, ex);
            }
        } else {
            mo.setRowCount(0);
            try {
                pst = connect.connexBd().prepareStatement("select * from ouvrages where intitule=?");
                pst.setString(1, jtsearch.getText());
                rs = pst.executeQuery();
                while (rs.next()) {
                    mo.addRow(new Object[]{
                        rs.getObject("reference"),
                        rs.getObject("intitule"),
                        rs.getObject("auteur"),
                        rs.getObject("edition"),
                        rs.getObject("annee_edi"),
                        rs.getBlob("photo"),
                        rs.getObject("path"),
                        rs.getObject("categorie"),
                        rs.getObject("description"),
                        rs.getObject("quantite")});
                }
                tabasouv.setModel(mo);
                if (mo.getRowCount() == 0) {
                    JOptionPane.showMessageDialog(this, "l'ouvrage n'existe pas");
                } else {
                    affichageouv(0);
                }
            } catch (SQLException ex) {
                Logger.getLogger(EspaceAssistant.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

    }//GEN-LAST:event_bsearchActionPerformed

    private void bquitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bquitActionPerformed
        // TODO add your handling code here:
        dispose();
    }//GEN-LAST:event_bquitActionPerformed

    private void discoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_discoActionPerformed
        // TODO add your handling code here:
        this.dispose();
        Authentification auth = new Authentification();
        auth.setVisible(true);

    }//GEN-LAST:event_discoActionPerformed

    private void blistreservActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_blistreservActionPerformed
        // TODO add your handling code here:
        reservationpanel.setVisible(true);
        emprunt.setVisible(false);
        jPanel1.setVisible(false);
        icone.setVisible(false);
        try {
            mr.setRowCount(0);
            mr.setColumnCount(0);
            mr.addColumn("Matricule");
            mr.addColumn("Référence");
            mr.addColumn("Date");
            mr.addColumn("Nom");
            mr.addColumn("Prénom");
            pst = cr.conreserv.connexBd().prepareStatement("select * from reservation");
            cr.rsreserv = pst.executeQuery();
            while (cr.rsreserv.next()) {
                mr.addRow(new Object[]{
                    cr.rsreserv.getObject("matric"),
                    cr.rsreserv.getObject("refouv"),
                    cr.rsreserv.getObject("date_resv"),
                    cr.rsreserv.getObject("nom"),
                    cr.rsreserv.getObject("prenom"),});
            }
            tabreserv.setModel(mr);
        } catch (SQLException ex) {
            Logger.getLogger(EspaceAssistant.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_blistreservActionPerformed

    private void bempruntActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bempruntActionPerformed
        // TODO add your handling code here:       
        emprunt.setVisible(true);
        icone.setVisible(false);
        reservationpanel.setVisible(false);
        jPanel1.setVisible(false);
    }//GEN-LAST:event_bempruntActionPerformed

    private void bvalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bvalActionPerformed
        // TODO add your handling code here:
        //table emprunt

        if (tabreserv.getSelectedRowCount() > 1) {
            for (int i = 0; i < tabreserv.getSelectedRowCount(); i++) {

                try {
                    pst = connect.connexBd().prepareStatement("insert into emprunt (matricule,ref,"
                            + "date_empr,date_ret,nom,prenom)values(?,?,?,?,?,?)");
                    pst.setString(1, tabreserv.getValueAt(tabreserv.getSelectedRow(), 0).toString());
                    pst.setString(2, (String) tabreserv.getValueAt(tabreserv.getSelectedRow() + i, 1));
                    SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");//le m doit etre en maj
                    String an = df.format(tabreserv.getValueAt(tabreserv.getSelectedRow(), 2));
                    pst.setString(3, an);
                    SimpleDateFormat dr = new SimpleDateFormat("yyyy-MM-dd");//le m doit etre en maj
                    String anr = dr.format(tabreserv.getValueAt(tabreserv.getSelectedRow(), 3));
                    pst.setString(4, anr);
                    pst.setString(5, tabreserv.getValueAt(tabreserv.getSelectedRow(), 4).toString());
                    pst.setString(6, tabreserv.getValueAt(tabreserv.getSelectedRow(), 5).toString());
                    pst.executeUpdate();
                    JOptionPane.showMessageDialog(this, "ROUGE");

                } catch (SQLException ex) {
                    Logger.getLogger(EspaceEtudiants.class.getName()).log(Level.SEVERE, null, ex);
                }
            }

        } else {
            try {
                pst = connect.connexBd().prepareStatement("insert into emprunt (matricule,ref,"
                        + "date_empr,date_ret,nom,prenom)values(?,?,?,?,?,?)");
                pst.setString(1, tabreserv.getValueAt(tabreserv.getSelectedRow(), 0).toString());
                pst.setString(2, (String) tabreserv.getValueAt(tabreserv.getSelectedRow(), 1));
                SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");//le m doit etre en maj
                String an = df.format(tabreserv.getValueAt(tabreserv.getSelectedRow(), 2));
                pst.setString(3, an);

                SimpleDateFormat dr = new SimpleDateFormat("yyyy-MM-dd");//le m doit etre en maj
                String anr = dr.format(jdret.getDate());
                pst.setString(4, anr);
                pst.setString(5, tabreserv.getValueAt(tabreserv.getSelectedRow(), 3).toString());
                pst.setString(6, tabreserv.getValueAt(tabreserv.getSelectedRow(), 4).toString());
                pst.executeUpdate();

            } catch (SQLException ex) {
                Logger.getLogger(EspaceEtudiants.class.getName()).log(Level.SEVERE, null, ex);
            }
            try {
                pst = connect.connexBd().prepareStatement("select quantite from ouvrages where reference='" + tabasouv.getValueAt(tabasouv.getSelectedRow(), 0) + "'");
                rs = pst.executeQuery();
                int q = 0;
                while (rs.next()) {
                    q = rs.getInt("quantite");

                }
                pst = connect.connexBd().prepareStatement("update ouvrages set quantite=? where reference='" + tabasouv.getValueAt(tabasouv.getSelectedRow(), 0) + "'");
                pst.setInt(1, q - 1);
                pst.executeUpdate();
            } catch (Exception ex) {
                Logger.getLogger(EspaceEtudiants.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        //2- on supprime la ligne selectionnée apres l'avoir ajouter a la table d'emprunt
        if (tabreserv.getSelectedRowCount() == 1) {
            if (JOptionPane.showConfirmDialog(this, "voulez-vous vraiment supprimer ?", "Suppression ",
                    JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
                try {
                    pst = connect.connexBd().prepareStatement("delete from reservation where refouv=?");
                    pst.setString(1, tabreserv.getValueAt(tabreserv.getSelectedRow(), 1).toString());
                    pst.executeUpdate();
                    JOptionPane.showMessageDialog(this, "La reservation a bien été supprimer", "Suppression", JOptionPane.INFORMATION_MESSAGE);

                } catch (SQLException ex) {
                    Logger.getLogger(EspaceAdministrateur.class.getName()).log(Level.SEVERE, null, ex);
                }

            }
        } else {
            for (int i = 0; i < tabreserv.getSelectedRowCount(); i++) {
                if (JOptionPane.showConfirmDialog(this, "voulez-vous vraiment supprimer ?", "Suppression ",
                        JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
                    try {
                        pst = connect.connexBd().prepareStatement("delete from reservation where refouv=?");
                        pst.setString(1, tabreserv.getValueAt(tabreserv.getSelectedRow() + i, 1).toString());
                        pst.executeUpdate();
                        JOptionPane.showMessageDialog(this, "La reservation a bien été supprimer", "Suppression", JOptionPane.INFORMATION_MESSAGE);

                    } catch (SQLException ex) {
                        Logger.getLogger(EspaceAdministrateur.class.getName()).log(Level.SEVERE, null, ex);
                    }

                }
            }
        }
        actuemprunt();
        actureserv();
    }//GEN-LAST:event_bvalActionPerformed

    private void bsuppempActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bsuppempActionPerformed

        if (tabemp.getSelectedRowCount() == 1) {
            if (JOptionPane.showConfirmDialog(this, "voulez-vous vraiment supprimer ?", "Suppression ",
                    JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
                try {
                    pst = connect.connexBd().prepareStatement("delete from emprunt where ref=?");
                    pst.setString(1, tabemp.getValueAt(tabemp.getSelectedRow(), 1).toString());
                    pst.executeUpdate();
                    JOptionPane.showMessageDialog(this, "L'emprunt a bien été supprimer",
                            "Suppression", JOptionPane.INFORMATION_MESSAGE);
                    //gerer la quantité
                    try {
                        pst = connect.connexBd().prepareStatement("select quantite from ouvrages where reference='" + tabasouv.getValueAt(tabasouv.getSelectedRow(), 0) + "'");
                        rs = pst.executeQuery();
                        int q = 0;
                        while (rs.next()) {
                            q = rs.getInt("quantite");

                        }
                        pst = connect.connexBd().prepareStatement("update ouvrages set quantite=? where reference='" + tabasouv.getValueAt(tabasouv.getSelectedRow(), 0) + "'");
                        pst.setInt(1, q + 1);
                        pst.executeUpdate();
                    } catch (Exception ex) {
                        Logger.getLogger(EspaceEtudiants.class.getName()).log(Level.SEVERE, null, ex);
                    }

                } catch (SQLException ex) {
                    Logger.getLogger(EspaceAdministrateur.class.getName()).log(Level.SEVERE, null, ex);
                }

            }
        } else {
            for (int i = 0; i < tabemp.getSelectedRowCount(); i++) {
                if (JOptionPane.showConfirmDialog(this, "voulez-vous vraiment supprimer ?", "Suppression ",
                        JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
                    try {
                        pst = connect.connexBd().prepareStatement("delete from emprunt where ref=?");
                        pst.setString(1, tabemp.getValueAt((tabemp.getSelectedRow() + i), 1).toString());
                        pst.executeUpdate();

                    } catch (SQLException ex) {
                        Logger.getLogger(EspaceAdministrateur.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    try {
                        pst = connect.connexBd().prepareStatement("select quantite from ouvrages where reference='" + tabasouv.getValueAt((tabasouv.getSelectedRow() + i), 0) + "'");
                        rs = pst.executeQuery();
                        int q = 0;
                        while (rs.next()) {
                            q = rs.getInt("quantite");

                        }
                        pst = connect.connexBd().prepareStatement("update ouvrages set quantite=? where reference='" + tabasouv.getValueAt((tabasouv.getSelectedRow() + i), 0) + "'");
                        pst.setInt(1, q - 1);
                        pst.executeUpdate();
                    } catch (Exception ex) {
                        Logger.getLogger(EspaceEtudiants.class.getName()).log(Level.SEVERE, null, ex);
                    }

                }
            }
            JOptionPane.showMessageDialog(this, "L'emprunt a bien été supprimer", "Suppression",
                    JOptionPane.INFORMATION_MESSAGE);

        }
        actuemprunt();
    }//GEN-LAST:event_bsuppempActionPerformed

    private void bordureActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bordureActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_bordureActionPerformed

    private void bprolongActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bprolongActionPerformed
        // TODO add your handling code here:
        jPanel1.setVisible(true);
        reservationpanel.setVisible(false);
        emprunt.setVisible(false);
        icone.setVisible(false);

    }//GEN-LAST:event_bprolongActionPerformed

    private void baddprolongActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_baddprolongActionPerformed
        // TODO add your handling code here:
        if (JOptionPane.showConfirmDialog(this, "voulez-vous vraiment modifier ?", "Modification ", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
            try {
                pst = connect.connexBd().prepareStatement("update emprunt set date_ret=? where matricule=?");
                pst.setString(1, tabrpol.getValueAt(tabrpol.getSelectedRow(), 5).toString());
                pst.setString(2, tabrpol.getValueAt(tabrpol.getSelectedRow(), 0).toString());
                // pst.setString(3, tabrpol.getValueAt(tabrpol.getSelectedRow(), 1).toString());
                pst.executeUpdate();
                JOptionPane.showMessageDialog(this, "Prolongation Acceptée");

            } catch (SQLException ex) {
                Logger.getLogger(EspaceAssistant.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        if (JOptionPane.showConfirmDialog(this, "voulez-vous vraiment supprimer ?", "Suppression ",
                JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
            try {
                pst = connect.connexBd().prepareStatement("delete from prolongation where reference=?");
                pst.setString(1, tabrpol.getValueAt((tabrpol.getSelectedRow()), 1).toString());
                pst.executeUpdate();

            } catch (SQLException ex) {
                Logger.getLogger(EspaceAssistant.class.getName()).log(Level.SEVERE, null, ex);
            }

        }
        actuemprunt();
        actupro();
    }//GEN-LAST:event_baddprolongActionPerformed

    private void bsearchEmpActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bsearchEmpActionPerformed
        try {
            memp.setRowCount(0);
            stat = connect.connexBd().createStatement();
            rs = stat.executeQuery("select * from emprunt where matricule='" + jtsemp.getText() + "'");
            //rs1 = stat1.executeQuery("select * from emprunt where nom='" + jtsemp.getText() + "'");

            while (rs.next()) {
                memp.addRow(new Object[]{rs.getObject("matricule"),
                    rs.getObject("ref"), rs.getObject("date_empr"), rs.getObject("date_ret"), rs.getObject("nom"), rs.getObject("prenom")});

            }
            tabemp.setModel(memp);
            /*  while (rs1.next()) {
             memp.addRow(new Object[]{rs.getObject("matricule"),
             rs.getObject("ref"), rs.getObject("date_empr"), rs.getObject("date_ret"), rs.getObject("nom")
             , rs.getObject("prenom")});

             }
             tabemp.setModel(memp);*/

            if (memp.getRowCount() == 0) {
                JOptionPane.showMessageDialog(this, "la reservation n'existe pas ", "Recherche reservation", JOptionPane.WARNING_MESSAGE);
            }
        } catch (SQLException ex) {
            Logger.getLogger(EspaceAssistant.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_bsearchEmpActionPerformed

    private void jtsearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jtsearchActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jtsearchActionPerformed

    private void cbsearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbsearchActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cbsearchActionPerformed

    private void bsearchreservActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bsearchreservActionPerformed
        try {
            mr.setRowCount(0);
            stat1 = connect.connexBd().createStatement();
            rs1 = stat1.executeQuery("select * from emprunt where matricule='" + jtsre.getText() + "'");
            //rs1 = stat1.executeQuery("select * from emprunt where nom='" + jtsemp.getText() + "'");

            while (rs1.next()) {
                mr.addRow(new Object[]{rs1.getObject("matricule"),
                    rs1.getObject("ref"), rs.getObject("date_empr"), rs1.getObject("date_ret"), rs1.getObject("nom"), rs1.getObject("prenom")});

            }
            tabreserv.setModel(mr);
            /*  while (rs1.next()) {
             memp.addRow(new Object[]{rs.getObject("matricule"),
             rs.getObject("ref"), rs.getObject("date_empr"), rs.getObject("date_ret"), rs.getObject("nom")
             , rs.getObject("prenom")});

             }
             tabemp.setModel(memp);*/

            if (mr.getRowCount() == 0) {
                JOptionPane.showMessageDialog(this, "la reservation n'existe pas ", "Recherche reservation", JOptionPane.WARNING_MESSAGE);
            }
        } catch (SQLException ex) {
            Logger.getLogger(EspaceAssistant.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_bsearchreservActionPerformed

    private void bpenalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bpenalActionPerformed
        // TODO add your handling code here:
        ajoutouinfo.setVisible(false);
        liste.setVisible(false);
        penalite.setVisible(true);
    }//GEN-LAST:event_bpenalActionPerformed

    private void baffichActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_baffichActionPerformed
        // TODO add your handling code here:
        penalite.setVisible(false);
        ajoutouinfo.setVisible(true);
        liste.setVisible(true);
    }//GEN-LAST:event_baffichActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(EspaceAssistant.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(EspaceAssistant.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(EspaceAssistant.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(EspaceAssistant.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new EspaceAssistant().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel ajoutouinfo;
    private javax.swing.JLabel auteur;
    private javax.swing.JButton baddprolong;
    private javax.swing.JButton baffich;
    private javax.swing.JButton baffichlist;
    private javax.swing.JButton bajout;
    private javax.swing.JButton bemprunt;
    private javax.swing.JButton blistreserv;
    private javax.swing.JTextField bordure;
    private javax.swing.JButton bpenal;
    private javax.swing.JButton bphoto;
    private javax.swing.JButton bprolong;
    private javax.swing.JButton bquit;
    private javax.swing.JButton bsearch;
    private javax.swing.JButton bsearchEmp;
    private javax.swing.JButton bsearchreserv;
    private javax.swing.JButton bsuppemp;
    private javax.swing.JButton bval;
    private javax.swing.JComboBox cbfiliereas;
    private javax.swing.JComboBox cbsearch;
    private javax.swing.JComboBox cbsp;
    private javax.swing.JLabel description;
    private javax.swing.JButton disco;
    private javax.swing.JLabel edition;
    private javax.swing.JPanel emprunt;
    private javax.swing.JLabel icone;
    private javax.swing.JLabel intitul;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JTextArea jadescrip;
    private com.toedter.calendar.JYearChooser jann;
    private com.toedter.calendar.JDateChooser jdret;
    private javax.swing.JTextField jpath;
    private javax.swing.JTextField jtaut;
    private javax.swing.JTextField jtedit;
    private javax.swing.JTextField jtintit;
    private javax.swing.JTextField jtquant;
    private javax.swing.JTextField jtsearch;
    private javax.swing.JTextField jtsemp;
    private javax.swing.JTextField jtsre;
    private javax.swing.JLabel lfond;
    private javax.swing.JPanel liste;
    public static javax.swing.JLabel lnom;
    private javax.swing.JLabel lphoto;
    public static javax.swing.JLabel lpnom;
    private javax.swing.JPanel penalite;
    private javax.swing.JPanel pimage;
    private javax.swing.JLabel reference;
    private javax.swing.JLabel refg;
    private javax.swing.JPanel reservationpanel;
    private javax.swing.JLabel specialité;
    private javax.swing.JTable tabasouv;
    private javax.swing.JTable tabemp;
    private javax.swing.JTable tabpenal;
    private javax.swing.JTable tabreserv;
    private javax.swing.JTable tabrpol;
    private javax.swing.JLabel titre;
    private javax.swing.JLabel vc;
    private javax.swing.JLabel year;
    // End of variables declaration//GEN-END:variables

    private void setIcon() {

        setIconImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("BIBLIO.png")));
    }
}
