/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Vue;

import java.awt.Image;
import java.awt.Toolkit;
import java.io.File;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileNameExtensionFilter;
import Modele.*;
import java.awt.print.PrinterException;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.sql.*;
import java.text.MessageFormat;
import java.text.SimpleDateFormat;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author ASUS VIVOBOOK
 */
public class EspaceAdministrateur extends javax.swing.JFrame {

    /**
     * Creates new form GestionOuvrageAdmin
     */
    ConnectBdd connect = new ConnectBdd();
    PreparedStatement pst, pste, psta;
    DefaultTableModel mo = new DefaultTableModel();
    DefaultTableModel mr = new DefaultTableModel();
    DefaultTableModel moas = new DefaultTableModel();
    DefaultTableModel memp = new DefaultTableModel();
    ResultSet rs;
    ConnectOuv co = new ConnectOuv();
    ConnectReservation cr = new ConnectReservation();
    ConnexionAssistant ca = new ConnexionAssistant();
    ConnectEmprunt cemp = new ConnectEmprunt();
    Statement stat;

    public EspaceAdministrateur() {

        initComponents();
        setLocationRelativeTo(this);
        setTitle("Espace Administrateur");
        setIcon();
        setSize(710, 1070);
        setResizable(false);
        jtype.setEditable(false);
        //Table emprunt
        try {
            memp.setRowCount(0);
            memp.setColumnCount(0);
            memp.addColumn("Matricule");
            memp.addColumn("Référence");
            memp.addColumn("Date");
            memp.addColumn("Date Retour");
            memp.addColumn("Nom");
            memp.addColumn("Prénom");
            pst = cemp.coemp.connexBd().prepareStatement("select * from emprunt");
            cemp.rsemp = pst.executeQuery();
            while (cemp.rsemp.next()) {
                memp.addRow(new Object[]{
                    cemp.rsemp.getObject("matricule"),
                    cemp.rsemp.getObject("ref"),
                    cemp.rsemp.getObject("date_empr"),
                    cemp.rsemp.getObject("date_ret"),
                    cemp.rsemp.getObject("nom"),
                    cemp.rsemp.getObject("prenom")
                    
                    
                });
            }
            tabemp.setModel(memp);
        } catch (SQLException ex) {
            Logger.getLogger(EspaceAssistant.class.getName()).log(Level.SEVERE, null, ex);
        }
        //Table des ouvrages
        try {
            mo.addColumn("Référence");
            mo.addColumn("Intitulé");
            mo.addColumn("Auteur");
            mo.addColumn("Edition");
            mo.addColumn("Année d'edition");
            mo.addColumn("Photo");
            mo.addColumn("Path");
            mo.addColumn("Spécialité");
            mo.addColumn("Description");
            mo.addColumn("quantite");
            pst = co.cono.connexBd().prepareStatement("select * from ouvrages");
            co.rso = pst.executeQuery();
            while (co.rso.next()) {
                mo.addRow(new Object[]{
                    co.rso.getObject("reference"),
                    co.rso.getObject("intitule"),
                    co.rso.getObject("auteur"),
                    co.rso.getObject("edition"),
                    co.rso.getObject("annee_edi"),
                    co.rso.getBlob("photo"),
                    co.rso.getObject("path"),
                    co.rso.getObject("categorie"),
                    co.rso.getObject("description"),
                    co.rso.getObject("quantite")
                });
            }
            tabouv.setModel(mo);
        } catch (SQLException ex) {
            Logger.getLogger(EspaceAdministrateur.class.getName()).log(Level.SEVERE, null, ex);
        }
        //Table Reservation
        try {
            mr.setRowCount(0);
            mr.setColumnCount(0);
            mr.addColumn("Matricule");
            mr.addColumn("Référence");
            mr.addColumn("Date");
            mr.addColumn("Nom");
            mr.addColumn("Prénom");
            pst = cr.conreserv.connexBd().prepareStatement("select * from reservation");
            cr.rsreserv = pst.executeQuery();
            while (cr.rsreserv.next()) {
                mr.addRow(new Object[]{
                    cr.rsreserv.getObject("matric"),
                    cr.rsreserv.getObject("refouv"),
                    cr.rsreserv.getObject("date_resv"),
                    cr.rsreserv.getObject("nom"),
                    cr.rsreserv.getObject("prenom")

                });
            }
            tabreserv.setModel(mr);
        } catch (SQLException ex) {
            Logger.getLogger(EspaceAssistant.class.getName()).log(Level.SEVERE, null, ex);
        }
        //table assistant
        try {
            moas.addColumn("ID");
            moas.addColumn("Nom");
            moas.addColumn("Prenom");
            moas.addColumn("Adresse");
            moas.addColumn("type");
            moas.addColumn("e-mail");
            moas.addColumn("Mot de passe");

            pst = ca.connexas.connexBd().prepareStatement("select * from assistant");
            ca.rsas = pst.executeQuery();
            while (ca.rsas.next()) {
                moas.addRow(new Object[]{
                    ca.rsas.getObject("ID"),
                    ca.rsas.getObject("nom"),
                    ca.rsas.getObject("prenom"),
                    ca.rsas.getObject("adr"),
                    ca.rsas.getObject("type"),
                    ca.rsas.getObject("email"),
                    ca.rsas.getObject("mdp"),});
            }
            tabass.setModel(moas);
        } catch (SQLException ex) {
            Logger.getLogger(EspaceAdministrateur.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    //ESPACE METHODE 
    //----------------------//
    //1- pour la gestion des ouvrages
    public void affichageouv(int ls) {
        lref.setText(tabouv.getValueAt(ls, 0).toString());
        jtintit.setText(tabouv.getValueAt(ls, 1).toString());
        jtauteur.setText(tabouv.getValueAt(ls, 2).toString());
        jtedit.setText(tabouv.getValueAt(ls, 3).toString());
        jannee.setYear(Integer.parseInt(tabouv.getValueAt(ls, 4).toString()));

        try {

            pst = connect.connexBd().prepareStatement("select photo from ouvrages where reference=?");
            pst.setString(1, tabouv.getValueAt(ls, 0).toString());
            rs = pst.executeQuery();
            while (rs.next()) {
                byte tabimg[] = rs.getBytes("photo");
                ImageIcon photo = new ImageIcon(tabimg);
                Image photorec = photo.getImage().getScaledInstance(lphoto.getWidth(), lphoto.getHeight(), Image.SCALE_SMOOTH);
                ImageIcon photorecf = new ImageIcon(photorec);
                lphoto.setIcon(photorecf);
            }
        } catch (SQLException ex) {
            Logger.getLogger(EspaceAdministrateur.class.getName()).log(Level.SEVERE, null, ex);
        }
        jtpath.setText(tabouv.getValueAt(ls, 6).toString());
        cbfili.setSelectedItem(tabouv.getValueAt(ls, 7));
        jadescri.setText(tabouv.getValueAt(ls, 8).toString());
        jtquant.setText(tabouv.getValueAt(ls, 9).toString());

    }

    public void reinitialisationouv() {
        lref.setText("");
        jtintit.setText(null);
        jtauteur.setText(null);
        jannee.setYear(2021);
        jtedit.setText(null);
        cbfili.setSelectedItem("Architecture");
        lphoto.setIcon(null);
        jtpath.setText(null);
        jadescri.setText(null);
        jtquant.setText(null);
    }

    public void actualisationouv() {
        mo.setRowCount(0);
        mo.setColumnCount(0);
        try {
            mo.setRowCount(0);
            mo.setColumnCount(0);

            mo.addColumn("Référence");
            mo.addColumn("Intitulé");
            mo.addColumn("Auteur");
            mo.addColumn("Edition");
            mo.addColumn("Année d'edition");
            mo.addColumn("Photo");
            mo.addColumn("Path");
            mo.addColumn("Spécialité");
            mo.addColumn("Description");
            mo.addColumn("quantite");
            pst = co.cono.connexBd().prepareStatement("select * from ouvrages");
            co.rso = pst.executeQuery();
            while (co.rso.next()) {
                mo.addRow(new Object[]{
                    co.rso.getObject("reference"),
                    co.rso.getObject("intitule"),
                    co.rso.getObject("auteur"),
                    co.rso.getObject("edition"),
                    co.rso.getObject("annee_edi"),
                    co.rso.getBlob("photo"),
                    co.rso.getObject("path"),
                    co.rso.getObject("categorie"),
                    co.rso.getObject("description"),
                    co.rso.getObject("quantite")
                });
            }
            tabouv.setModel(mo);
        } catch (SQLException ex) {
            Logger.getLogger(EspaceAdministrateur.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    //2- pour la gestion des etudiant
    public void actualisationreserv() {
        try {
            mr.setRowCount(0);
            mr.setColumnCount(0);
            mr.addColumn("Matricule");
            mr.addColumn("Référence");
            mr.addColumn("Date");
            mr.addColumn("Nom");
            mr.addColumn("Prénom");
            pst = cr.conreserv.connexBd().prepareStatement("select * from reservation");
            cr.rsreserv = pst.executeQuery();
            while (cr.rsreserv.next()) {
                mr.addRow(new Object[]{
                    cr.rsreserv.getObject("matric"),
                    cr.rsreserv.getObject("refouv"),
                    cr.rsreserv.getObject("date_resv"),
                    cr.rsreserv.getObject("nom"),
                    cr.rsreserv.getObject("prenom"),});
            }
            tabreserv.setModel(mr);
        } catch (SQLException ex) {
            Logger.getLogger(EspaceAssistant.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    //actualisation emprunt
    public void actuemp() {
        try {
            memp.setRowCount(0);
            memp.setColumnCount(0);
            memp.addColumn("Matricule");
            memp.addColumn("Référence");
            memp.addColumn("Date");
            memp.addColumn("Nom");
            memp.addColumn("Prénom");
            pst = cemp.coemp.connexBd().prepareStatement("select * from emprunt");
            cemp.rsemp = pst.executeQuery();
            while (cemp.rsemp.next()) {
                memp.addRow(new Object[]{
                    cemp.rsemp.getObject("matricule"),
                    cemp.rsemp.getObject("ref"),
                    cemp.rsemp.getObject("date_empr"),
                    cemp.rsemp.getObject("nom"),
                    cemp.rsemp.getObject("prenom")
                });
            }
            tabemp.setModel(memp);
        } catch (SQLException ex) {
            Logger.getLogger(EspaceAssistant.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    //2- pour la gestion des assistant

    public void actualisationassis() {
        try {
            moas.setColumnCount(0);
            moas.setRowCount(0);
            moas.addColumn("ID");
            moas.addColumn("Nom");
            moas.addColumn("Prenom");
            moas.addColumn("Adresse");
            moas.addColumn("type");
            moas.addColumn("e-mail");
            moas.addColumn("Mot de passe");

            pst = ca.connexas.connexBd().prepareStatement("select * from assistant");
            ca.rsas = pst.executeQuery();
            while (ca.rsas.next()) {
                moas.addRow(new Object[]{
                    ca.rsas.getObject("ID"),
                    ca.rsas.getObject("nom"),
                    ca.rsas.getObject("prenom"),
                    ca.rsas.getObject("adr"),
                    ca.rsas.getObject("type"),
                    ca.rsas.getObject("email"),
                    ca.rsas.getObject("mdp"),});
            }
            tabass.setModel(moas);
        } catch (SQLException ex) {
            Logger.getLogger(EspaceAdministrateur.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void reinitialisationass() {

        jnom.setText(null);
        jpnom.setText(null);
        jadr.setText(null);
        jemail.setText(null);
        jmdp.setText(null);
    }

    public void afficheassistant(int rs) {

        jid.setText(tabass.getValueAt(rs, 0).toString());
        jnom.setText(tabass.getValueAt(rs, 1).toString());
        jpnom.setText(tabass.getValueAt(rs, 2).toString());
        jadr.setText(tabass.getValueAt(rs, 3).toString());
        jtype.setText(tabass.getValueAt(rs, 4).toString());
        jemail.setText(tabass.getValueAt(rs, 5).toString());
        jmdp.setText(tabass.getValueAt(rs, 6).toString());
    }

    //----------------------//
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTabbedPane2 = new javax.swing.JTabbedPane();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        ouvrages = new javax.swing.JPanel();
        liste = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tabouv = new javax.swing.JTable();
        MAJ = new javax.swing.JPanel();
        bajout = new javax.swing.JButton();
        bsupp = new javax.swing.JButton();
        bmodif = new javax.swing.JButton();
        bimpress = new javax.swing.JButton();
        INFO = new javax.swing.JPanel();
        intitulé = new javax.swing.JLabel();
        auteur = new javax.swing.JLabel();
        annee = new javax.swing.JLabel();
        edition = new javax.swing.JLabel();
        filiere = new javax.swing.JLabel();
        descript = new javax.swing.JLabel();
        jtintit = new javax.swing.JTextField();
        jtauteur = new javax.swing.JTextField();
        jtedit = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        jadescri = new javax.swing.JTextArea();
        cbfili = new javax.swing.JComboBox();
        jPanel2 = new javax.swing.JPanel();
        lphoto = new javax.swing.JLabel();
        bimg = new javax.swing.JButton();
        jtpath = new javax.swing.JTextField();
        jannee = new com.toedter.calendar.JYearChooser();
        reference = new javax.swing.JLabel();
        lref = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jtquant = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        disco = new javax.swing.JLabel();
        fond = new javax.swing.JLabel();
        Etudiant = new javax.swing.JPanel();
        jtsearch = new javax.swing.JTextField();
        brech = new javax.swing.JButton();
        jPanel6 = new javax.swing.JPanel();
        jScrollPane5 = new javax.swing.JScrollPane();
        tabemp = new javax.swing.JTable();
        bexit = new javax.swing.JButton();
        titre = new javax.swing.JLabel();
        listeetud = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        tabreserv = new javax.swing.JTable();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        fondetud = new javax.swing.JLabel();
        Assistant = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane4 = new javax.swing.JScrollPane();
        tabass = new javax.swing.JTable();
        jPanel4 = new javax.swing.JPanel();
        nom = new javax.swing.JLabel();
        prenom = new javax.swing.JLabel();
        adress = new javax.swing.JLabel();
        mail = new javax.swing.JLabel();
        mdp = new javax.swing.JLabel();
        jnom = new javax.swing.JTextField();
        jpnom = new javax.swing.JTextField();
        jadr = new javax.swing.JTextField();
        jemail = new javax.swing.JTextField();
        jmdp = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jtype = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jid = new javax.swing.JTextField();
        bajoutas = new javax.swing.JButton();
        bsuppas = new javax.swing.JButton();
        bseearch = new javax.swing.JButton();
        jtrechas = new javax.swing.JTextField();
        bmodaas = new javax.swing.JButton();
        titreas = new javax.swing.JLabel();
        fond1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jTabbedPane1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jTabbedPane1.setForeground(new java.awt.Color(0, 0, 204));
        jTabbedPane1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTabbedPane1MouseClicked(evt);
            }
        });

        ouvrages.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        liste.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED), "Liste des Ouvrages", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Calibri", 3, 24), new java.awt.Color(0, 0, 204))); // NOI18N
        liste.setOpaque(false);

        tabouv.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        tabouv.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tabouvMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(tabouv);

        javax.swing.GroupLayout listeLayout = new javax.swing.GroupLayout(liste);
        liste.setLayout(listeLayout);
        listeLayout.setHorizontalGroup(
            listeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(listeLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 598, Short.MAX_VALUE)
                .addContainerGap())
        );
        listeLayout.setVerticalGroup(
            listeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(listeLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 140, Short.MAX_VALUE)
                .addContainerGap())
        );

        ouvrages.add(liste, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 790, 640, 210));

        MAJ.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED), "Mise à jour", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Calibri", 3, 24), new java.awt.Color(0, 0, 204))); // NOI18N
        MAJ.setOpaque(false);

        bajout.setFont(new java.awt.Font("Calibri", 1, 20)); // NOI18N
        bajout.setForeground(new java.awt.Color(0, 0, 153));
        bajout.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ajouter.png"))); // NOI18N
        bajout.setText("Ajouter");
        bajout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bajoutActionPerformed(evt);
            }
        });

        bsupp.setFont(new java.awt.Font("Calibri", 1, 20)); // NOI18N
        bsupp.setForeground(new java.awt.Color(0, 0, 153));
        bsupp.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/supprimer.png"))); // NOI18N
        bsupp.setText("Supprimer");
        bsupp.setToolTipText("pour supp");
        bsupp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bsuppActionPerformed(evt);
            }
        });

        bmodif.setFont(new java.awt.Font("Calibri", 1, 20)); // NOI18N
        bmodif.setForeground(new java.awt.Color(0, 0, 153));
        bmodif.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/update.png"))); // NOI18N
        bmodif.setText("Modifier");
        bmodif.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bmodifActionPerformed(evt);
            }
        });

        bimpress.setFont(new java.awt.Font("Calibri", 1, 20)); // NOI18N
        bimpress.setForeground(new java.awt.Color(0, 0, 153));
        bimpress.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/print.png"))); // NOI18N
        bimpress.setText("Impression");
        bimpress.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bimpressActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout MAJLayout = new javax.swing.GroupLayout(MAJ);
        MAJ.setLayout(MAJLayout);
        MAJLayout.setHorizontalGroup(
            MAJLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(MAJLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(bajout)
                .addGap(81, 81, 81)
                .addGroup(MAJLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(MAJLayout.createSequentialGroup()
                        .addComponent(bimpress)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(MAJLayout.createSequentialGroup()
                        .addComponent(bsupp)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 67, Short.MAX_VALUE)
                        .addComponent(bmodif)
                        .addGap(62, 62, 62))))
        );
        MAJLayout.setVerticalGroup(
            MAJLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(MAJLayout.createSequentialGroup()
                .addGroup(MAJLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(bajout)
                    .addComponent(bsupp)
                    .addComponent(bmodif))
                .addGap(18, 18, 18)
                .addComponent(bimpress)
                .addGap(0, 4, Short.MAX_VALUE))
        );

        ouvrages.add(MAJ, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 660, 640, 130));

        INFO.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED), "Formulaire", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Calibri", 3, 30), new java.awt.Color(0, 0, 204))); // NOI18N
        INFO.setOpaque(false);
        INFO.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        intitulé.setFont(new java.awt.Font("Calibri", 1, 20)); // NOI18N
        intitulé.setForeground(new java.awt.Color(0, 0, 153));
        intitulé.setText("Intitulé :");
        INFO.add(intitulé, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 90, -1, -1));

        auteur.setFont(new java.awt.Font("Calibri", 1, 20)); // NOI18N
        auteur.setForeground(new java.awt.Color(0, 0, 153));
        auteur.setText("Auteur :");
        INFO.add(auteur, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 130, -1, -1));

        annee.setFont(new java.awt.Font("Calibri", 1, 20)); // NOI18N
        annee.setForeground(new java.awt.Color(0, 0, 153));
        annee.setText("Année :");
        INFO.add(annee, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 180, -1, -1));

        edition.setFont(new java.awt.Font("Calibri", 1, 20)); // NOI18N
        edition.setForeground(new java.awt.Color(0, 0, 153));
        edition.setText("Edition :");
        INFO.add(edition, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 230, -1, -1));

        filiere.setFont(new java.awt.Font("Calibri", 1, 20)); // NOI18N
        filiere.setForeground(new java.awt.Color(0, 0, 153));
        filiere.setText("Filière :");
        INFO.add(filiere, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 280, -1, -1));

        descript.setFont(new java.awt.Font("Calibri", 1, 20)); // NOI18N
        descript.setForeground(new java.awt.Color(0, 0, 153));
        descript.setText("Description :");
        INFO.add(descript, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 320, -1, -1));

        jtintit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jtintitActionPerformed(evt);
            }
        });
        INFO.add(jtintit, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 80, 140, -1));
        INFO.add(jtauteur, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 130, 140, -1));
        INFO.add(jtedit, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 230, 140, -1));

        jadescri.setColumns(20);
        jadescri.setRows(5);
        jScrollPane1.setViewportView(jadescri);

        INFO.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 320, 460, -1));

        cbfili.setFont(new java.awt.Font("Calibri", 1, 18)); // NOI18N
        cbfili.setForeground(new java.awt.Color(0, 51, 204));
        cbfili.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Architecture", "Automatique", "Chimie", "Eléctronique", "Géologie", "Informatique", "Mathematique", "Mécanique", "Médecine", "Physique", "Réseaux", "Statistique" }));
        cbfili.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                cbfiliFocusLost(evt);
            }
        });
        INFO.add(cbfili, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 280, 140, -1));

        jPanel2.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lphoto, javax.swing.GroupLayout.DEFAULT_SIZE, 146, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lphoto, javax.swing.GroupLayout.DEFAULT_SIZE, 154, Short.MAX_VALUE)
                .addContainerGap())
        );

        INFO.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 50, 180, 190));

        bimg.setFont(new java.awt.Font("Calibri", 3, 16)); // NOI18N
        bimg.setForeground(new java.awt.Color(0, 0, 204));
        bimg.setText("Charger la photo");
        bimg.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bimgActionPerformed(evt);
            }
        });
        INFO.add(bimg, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 250, 180, -1));
        INFO.add(jtpath, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 280, 180, -1));
        INFO.add(jannee, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 180, 140, -1));

        reference.setFont(new java.awt.Font("Calibri", 1, 20)); // NOI18N
        reference.setForeground(new java.awt.Color(0, 0, 153));
        reference.setText("Réfèrence :");
        INFO.add(reference, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 50, -1, -1));

        lref.setFont(new java.awt.Font("Calibri", 1, 20)); // NOI18N
        lref.setForeground(new java.awt.Color(0, 51, 153));
        INFO.add(lref, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 50, 150, 20));

        jLabel2.setFont(new java.awt.Font("Calibri", 1, 20)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 0, 153));
        jLabel2.setText("Quantité :");
        INFO.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 420, -1, -1));
        INFO.add(jtquant, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 420, 140, -1));

        ouvrages.add(INFO, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 190, 640, 460));

        jLabel1.setFont(new java.awt.Font("Calibri", 3, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Gestion des ouvrages");
        ouvrages.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 60, -1, -1));

        disco.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8_logout_rounded_down_30px_1.png"))); // NOI18N
        disco.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        disco.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                discoMouseClicked(evt);
            }
        });
        ouvrages.add(disco, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 20, -1, -1));

        fond.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/listeouv.png"))); // NOI18N
        ouvrages.add(fond, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        jTabbedPane1.addTab("Ouvrages", ouvrages);

        Etudiant.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        Etudiant.add(jtsearch, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 180, 220, 30));

        brech.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/search.png"))); // NOI18N
        brech.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                brechActionPerformed(evt);
            }
        });
        Etudiant.add(brech, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 180, -1, 30));

        jPanel6.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED), "Emprunt", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Calibri", 3, 18), new java.awt.Color(0, 0, 204))); // NOI18N
        jPanel6.setOpaque(false);

        tabemp.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        jScrollPane5.setViewportView(tabemp);

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap(21, Short.MAX_VALUE)
                .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 245, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(28, Short.MAX_VALUE))
        );

        Etudiant.add(jPanel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 270, 500, 320));

        bexit.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/exit.png"))); // NOI18N
        bexit.setOpaque(false);
        bexit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bexitActionPerformed(evt);
            }
        });
        Etudiant.add(bexit, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 940, 80, 80));

        titre.setFont(new java.awt.Font("Calibri", 3, 36)); // NOI18N
        titre.setForeground(new java.awt.Color(255, 255, 255));
        titre.setText("Consulter la liste des Reservations ");
        Etudiant.add(titre, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 20, 550, -1));

        listeetud.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED), "Reservation", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Calibri", 3, 18), new java.awt.Color(0, 0, 204))); // NOI18N
        listeetud.setOpaque(false);

        tabreserv.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        tabreserv.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tabreservMouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(tabreserv);

        javax.swing.GroupLayout listeetudLayout = new javax.swing.GroupLayout(listeetud);
        listeetud.setLayout(listeetudLayout);
        listeetudLayout.setHorizontalGroup(
            listeetudLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(listeetudLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 458, Short.MAX_VALUE)
                .addContainerGap())
        );
        listeetudLayout.setVerticalGroup(
            listeetudLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(listeetudLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 259, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(64, Short.MAX_VALUE))
        );

        Etudiant.add(listeetud, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 600, 500, 370));

        jLabel4.setFont(new java.awt.Font("Calibri", 3, 48)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("ET");
        Etudiant.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 60, -1, -1));

        jLabel5.setFont(new java.awt.Font("Calibri", 3, 36)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Des Emprunts");
        Etudiant.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 110, -1, -1));

        fondetud.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/listeouv.png"))); // NOI18N
        Etudiant.add(fondetud, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        jTabbedPane1.addTab("Consultaion", Etudiant);

        Assistant.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED), "Listes des Assistants", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Calibri", 3, 18), new java.awt.Color(0, 0, 204))); // NOI18N
        jPanel3.setForeground(new java.awt.Color(0, 51, 153));
        jPanel3.setOpaque(false);

        tabass.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        tabass.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tabassMouseClicked(evt);
            }
        });
        jScrollPane4.setViewportView(tabass);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane4, javax.swing.GroupLayout.DEFAULT_SIZE, 496, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 343, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(19, Short.MAX_VALUE))
        );

        Assistant.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 590, 540, 410));

        jPanel4.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED), "Mise à jour", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Calibri", 3, 18), new java.awt.Color(0, 0, 204))); // NOI18N
        jPanel4.setOpaque(false);

        nom.setFont(new java.awt.Font("Calibri", 3, 18)); // NOI18N
        nom.setForeground(new java.awt.Color(0, 0, 204));
        nom.setText("Nom :");

        prenom.setFont(new java.awt.Font("Calibri", 3, 18)); // NOI18N
        prenom.setForeground(new java.awt.Color(0, 0, 204));
        prenom.setText("Prénom :");

        adress.setFont(new java.awt.Font("Calibri", 3, 18)); // NOI18N
        adress.setForeground(new java.awt.Color(0, 0, 204));
        adress.setText("Adresse :");

        mail.setFont(new java.awt.Font("Calibri", 3, 18)); // NOI18N
        mail.setForeground(new java.awt.Color(0, 0, 204));
        mail.setText("email :");

        mdp.setFont(new java.awt.Font("Calibri", 3, 18)); // NOI18N
        mdp.setForeground(new java.awt.Color(0, 0, 204));
        mdp.setText("Mot de passe :");

        jLabel9.setFont(new java.awt.Font("Calibri", 3, 18)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(0, 0, 204));
        jLabel9.setText("Type :");

        jtype.setText("Assistant");

        jLabel3.setFont(new java.awt.Font("Calibri", 3, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 0, 204));
        jLabel3.setText("ID :");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(mail)
                            .addComponent(prenom)
                            .addComponent(nom)
                            .addComponent(adress))
                        .addGap(58, 58, 58)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jadr)
                            .addComponent(jemail, javax.swing.GroupLayout.DEFAULT_SIZE, 155, Short.MAX_VALUE)
                            .addComponent(jpnom)
                            .addComponent(jnom)))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(mdp)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jmdp)))
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel9)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jtype, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(79, 79, 79)
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jid, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jnom, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(nom)
                    .addComponent(jLabel3)
                    .addComponent(jid, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jpnom, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(prenom))
                .addGap(18, 18, 18)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jadr, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(adress, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jemail, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(mail))
                .addGap(18, 18, 18)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(mdp)
                    .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jmdp, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel9)
                        .addComponent(jtype, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        Assistant.add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 240, 540, 260));

        bajoutas.setFont(new java.awt.Font("Calibri", 3, 18)); // NOI18N
        bajoutas.setForeground(new java.awt.Color(0, 0, 204));
        bajoutas.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ajouter.png"))); // NOI18N
        bajoutas.setText("Ajouter");
        bajoutas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bajoutasActionPerformed(evt);
            }
        });
        Assistant.add(bajoutas, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 540, 140, -1));

        bsuppas.setFont(new java.awt.Font("Calibri", 3, 18)); // NOI18N
        bsuppas.setForeground(new java.awt.Color(0, 0, 204));
        bsuppas.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/supprimer.png"))); // NOI18N
        bsuppas.setText("Supprimer");
        bsuppas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bsuppasActionPerformed(evt);
            }
        });
        Assistant.add(bsuppas, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 540, 140, -1));

        bseearch.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/search.png"))); // NOI18N
        bseearch.setOpaque(false);
        bseearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bseearchActionPerformed(evt);
            }
        });
        Assistant.add(bseearch, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 180, -1, -1));
        Assistant.add(jtrechas, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 180, 170, 40));

        bmodaas.setFont(new java.awt.Font("Calibri", 3, 18)); // NOI18N
        bmodaas.setForeground(new java.awt.Color(0, 0, 204));
        bmodaas.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/update.png"))); // NOI18N
        bmodaas.setText("Modifier");
        bmodaas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bmodaasActionPerformed(evt);
            }
        });
        Assistant.add(bmodaas, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 540, -1, -1));

        titreas.setFont(new java.awt.Font("Calibri", 3, 36)); // NOI18N
        titreas.setForeground(new java.awt.Color(255, 255, 255));
        titreas.setText("GESTION DES ASSISTANTS");
        Assistant.add(titreas, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 60, -1, -1));

        fond1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/listeouv.png"))); // NOI18N
        Assistant.add(fond1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        jTabbedPane1.addTab("Assistant", Assistant);

        getContentPane().add(jTabbedPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 710, 1070));

        pack();
    }// </editor-fold>//GEN-END:initComponents
     String str;
    private void bimgActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bimgActionPerformed
        // TODO add your handling code here:
        JFileChooser fileChooser = new JFileChooser();
        //préciser le dossier ou se trouvent les images
        fileChooser.setCurrentDirectory(new File("C:\\Users\\ASUS VIVOBOOK\\Desktop\\PFC\\ouvrages"));
        FileNameExtensionFilter filter = new FileNameExtensionFilter("Image", "jpg", "png", "gif");
        fileChooser.addChoosableFileFilter(filter);//why
        int result = fileChooser.showOpenDialog(null);//why
        if (result == JFileChooser.APPROVE_OPTION) {

            File fichierselectionne = fileChooser.getSelectedFile();
            String path = fichierselectionne.getAbsolutePath();
            ImageIcon img = new ImageIcon(path);
            Image imgrec = img.getImage();
            Image nimage = imgrec.getScaledInstance(lphoto.getWidth(),
                    lphoto.getHeight(), Image.SCALE_SMOOTH);
            ImageIcon imgfinal = new ImageIcon(nimage);

            lphoto.setIcon(imgfinal);
            str = path;
            jtpath.setText(str);
        } else if (result == JFileChooser.CANCEL_OPTION) {
            JOptionPane.showMessageDialog(null, "Aucun choix effectué");
        }
    }//GEN-LAST:event_bimgActionPerformed

    private void jtintitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jtintitActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jtintitActionPerformed

    private void bajoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bajoutActionPerformed
        if (lref.getText().equals(null)|| jtintit.getText().equals(null)|| jtedit.getText().equals(null)||jtauteur.getText().equals(null)
                || jtpath.getText().equals(null) || jadescri.getText().equals(null)|| jtquant.getText().equals("") ) {
            JOptionPane.showMessageDialog(this, "Veuillez remplir tout les champs");
        }
        else{
        try {

            pst = connect.connexBd().prepareStatement("insert into ouvrages(reference,intitule,auteur,annee_edi,"
                    + "edition,photo,path,categorie,description,quantite) values"
                    + "(?,?,?,?,?,?,?,?,?,?)");
            pst.setString(1, lref.getText());
            pst.setString(2, jtintit.getText());
            pst.setString(3, jtauteur.getText());
            pst.setObject(4, jannee.getYear());
            pst.setString(5, jtedit.getText());

            // pour ajouter la photo
            try {
                //1-lire la photo
                InputStream rimg = new FileInputStream(jtpath.getText());
                //2-mettre la photo
                pst.setBlob(6, rimg);
            } catch (FileNotFoundException ex) {
                Logger.getLogger(EspaceAdministrateur.class.getName()).log(Level.SEVERE, null, ex);
            }
            pst.setString(7, jtpath.getText());
            pst.setString(8, cbfili.getSelectedItem().toString());
            pst.setString(9, jadescri.getText());
            pst.setString(10, jtquant.getText());

            // envoyer la requete
            pst.executeUpdate();
            JOptionPane.showMessageDialog(this, "Ouvrage ajouté");
        } catch (SQLException ex) {
            Logger.getLogger(EspaceAdministrateur.class.getName()).log(Level.SEVERE, null, ex);
        }
        reinitialisationouv();
        actualisationouv();
        }
    }//GEN-LAST:event_bajoutActionPerformed

    private void bsuppActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bsuppActionPerformed
        if (JOptionPane.showConfirmDialog(this, "voulez-vous vraiment supprimer ?", "Suppression ", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
            try {
                pst = connect.connexBd().prepareStatement("delete from ouvrages where reference=?");
                pst.setString(1, lref.getText());
                pst.executeUpdate();
                JOptionPane.showMessageDialog(this, "L'ouvrage a bien été supprimer", "Suppression", JOptionPane.INFORMATION_MESSAGE);

            } catch (SQLException ex) {
                Logger.getLogger(EspaceAdministrateur.class.getName()).log(Level.SEVERE, null, ex);
            }

        }
        reinitialisationouv();
        actualisationouv();

    }//GEN-LAST:event_bsuppActionPerformed

    private void cbfiliFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_cbfiliFocusLost
        lref.setText((cbfili.getSelectedItem().toString().substring(0, 3) + jtintit.getText().substring(0, 2)).toUpperCase()
                + jannee.getYear());
    }//GEN-LAST:event_cbfiliFocusLost

    private void tabouvMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tabouvMouseClicked
        // TODO add your handling code here:
        affichageouv(tabouv.getSelectedRow());
    }//GEN-LAST:event_tabouvMouseClicked

    private void jTabbedPane1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTabbedPane1MouseClicked

    }//GEN-LAST:event_jTabbedPane1MouseClicked

    private void tabreservMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tabreservMouseClicked
        // TODO add your handling code here:

    }//GEN-LAST:event_tabreservMouseClicked

    private void bmodifActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bmodifActionPerformed
        // TODO add your handling code here:
        if (JOptionPane.showConfirmDialog(this, "voulez-vous vraiment modifier ?", "Modification ", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
            try {
                pst = connect.connexBd().prepareStatement("update ouvrages set intitule=?,auteur=?"
                        + ",edition=?,annee_edi=?,photo=?,path=?,categorie=?,description=?,quantite=?  where reference=?");
                pst.setString(1, jtintit.getText());
                pst.setString(2, jtauteur.getText());
                pst.setObject(4, jannee.getYear());
                pst.setString(3, jtedit.getText());
                // pour ajouter la photo
                try {
                    //1-lire la photo
                    InputStream rimg = new FileInputStream(jtpath.getText());
                    //2-mettre la photo
                    pst.setBlob(5, rimg);
                } catch (FileNotFoundException ex) {
                    Logger.getLogger(EspaceAdministrateur.class.getName()).log(Level.SEVERE, null, ex);
                }
                pst.setString(6, jtpath.getText());
                pst.setString(7, cbfili.getSelectedItem().toString());
                pst.setString(8, jadescri.getText());

                // envoyer la requete
                pst.setString(10, tabouv.getValueAt(tabouv.getSelectedRow(), 0).toString());
                pst.setString(9, jtquant.getText());
                pst.executeUpdate();
                JOptionPane.showMessageDialog(this, "modification ");
            } catch (SQLException ex) {
                Logger.getLogger(EspaceAdministrateur.class.getName()).log(Level.SEVERE, null, ex);
            }
            reinitialisationouv();
            actualisationouv();

        }

    }//GEN-LAST:event_bmodifActionPerformed

    private void brechActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_brechActionPerformed
        // TODO add your handling code here:
        mr.setRowCount(0);
        try {
            pst = connect.connexBd().prepareStatement("select * from reservation where nom=?");
            pst.setString(1, jtsearch.getText());
            rs = pst.executeQuery();
            while (rs.next()) {
                mr.addRow(new Object[]{
                    rs.getObject("matric"),
                    rs.getObject("refouv"),
                    rs.getObject("date_resv"),
                    rs.getObject("nom"),
                    rs.getObject("prenom")

                });
            }
            tabreserv.setModel(mr);
            if (mr.getRowCount() == 0) {
                JOptionPane.showMessageDialog(this, "l'etudiant n'existe pas");
            } else {

            }
        } catch (SQLException ex) {
            Logger.getLogger(EspaceAdministrateur.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_brechActionPerformed

    private void bexitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bexitActionPerformed
        // TODO add your handling code here:
        dispose();
    }//GEN-LAST:event_bexitActionPerformed

    private void bajoutasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bajoutasActionPerformed
        // TODO add your handling code here:
        try {

            psta = connect.connexBd().prepareStatement("insert into assistant(nom,prenom,adr,"
                    + "type,email,mdp) values"
                    + "(?,?,?,?,?,?)");

            psta.setString(1, jnom.getText());
            psta.setString(2, jpnom.getText());
            psta.setString(3, jadr.getText());
            psta.setString(4, jtype.getText());
            psta.setString(5, jemail.getText());
            psta.setString(6, jmdp.getText());

            psta.executeUpdate();
            JOptionPane.showMessageDialog(this, "assistant ajouté");
        } catch (SQLException ex) {
            Logger.getLogger(EspaceAdministrateur.class.getName()).log(Level.SEVERE, null, ex);
        }
        reinitialisationass();
        actualisationassis();


    }//GEN-LAST:event_bajoutasActionPerformed

    private void bsuppasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bsuppasActionPerformed
        // Delete from enseignant where ID='" + tabens.getValueAt(tabens.getSelectedRow(), 0)Delete from enseignant where ID='" + tabens.getValueAt(tabens.getSelectedRow(), 0) + "'"
        if (JOptionPane.showConfirmDialog(this, "voulez-vous vraiment supprimer ?", "Suppression ", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
            try {
                psta = connect.connexBd().prepareStatement("Delete from assistant where ID='"
                        + tabass.getValueAt(tabass.getSelectedRow(), 0) + "'");

                psta.executeUpdate();
                JOptionPane.showMessageDialog(this, "L'assistant a bien été supprimer", "Suppression", JOptionPane.INFORMATION_MESSAGE);

            } catch (SQLException ex) {
                Logger.getLogger(EspaceAdministrateur.class.getName()).log(Level.SEVERE, null, ex);
            }
            actualisationassis();
            reinitialisationass();

        }
    }//GEN-LAST:event_bsuppasActionPerformed

    private void bseearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bseearchActionPerformed
        // TODO add your handling code here:
        moas.setRowCount(0);
        try {
            psta = connect.connexBd().prepareStatement("select * from assistant where nom=?");
            psta.setString(1, jtrechas.getText());
            rs = psta.executeQuery();
            while (rs.next()) {
                moas.addRow(new Object[]{
                    rs.getObject("ID"),
                    rs.getObject("nom"),
                    rs.getObject("prenom"),
                    rs.getObject("adr"),
                    rs.getObject("type"),
                    rs.getObject("email"),
                    rs.getObject("mdp")
                });
            }
            tabass.setModel(moas);
            if (moas.getRowCount() == 0) {
                JOptionPane.showMessageDialog(this, "l'assistant n'existe pas");
            } else {
                afficheassistant(0);
            }
        } catch (SQLException ex) {
            Logger.getLogger(EspaceAdministrateur.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_bseearchActionPerformed

    private void tabassMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tabassMouseClicked
        // TODO add your handling code here:
        afficheassistant(tabass.getSelectedRow());
    }//GEN-LAST:event_tabassMouseClicked

    private void discoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_discoMouseClicked
        // TODO add your handling code here:
        dispose();
        Authentification an = new Authentification();
        an.setVisible(true);
    }//GEN-LAST:event_discoMouseClicked

    private void bmodaasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bmodaasActionPerformed
        if (JOptionPane.showConfirmDialog(this, "voulez-vous vraiment modifier ?", "Modification ", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
            try {
                pst = connect.connexBd().prepareStatement("update assistant set nom=?"
                        + ",prenom=?,adr=?,type=?,email=?,mdp=? where ID=? ");
                pst.setString(1, jnom.getText());
                pst.setString(2, jpnom.getText());
                pst.setString(3, jadr.getText());
                pst.setString(4, jtype.getText());
                pst.setString(5, jemail.getText());
                pst.setString(6, jmdp.getText());
                pst.setString(7, jid.getText());
                pst.executeUpdate();
            } catch (SQLException ex) {
                Logger.getLogger(EspaceAdministrateur.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        actualisationassis();
        reinitialisationass();
    }//GEN-LAST:event_bmodaasActionPerformed

    private void bimpressActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bimpressActionPerformed
        // TODO add your handling code here:

        MessageFormat header = new MessageFormat("Liste des ouvrages");
        MessageFormat footer = new MessageFormat("");
        try {
            tabouv.print(JTable.PrintMode.NORMAL, header, footer);
        } catch (PrinterException ex) {
            Logger.getLogger(EspaceAdministrateur.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_bimpressActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(EspaceAdministrateur.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(EspaceAdministrateur.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(EspaceAdministrateur.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(EspaceAdministrateur.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new EspaceAdministrateur().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel Assistant;
    private javax.swing.JPanel Etudiant;
    private javax.swing.JPanel INFO;
    private javax.swing.JPanel MAJ;
    private javax.swing.JLabel adress;
    private javax.swing.JLabel annee;
    private javax.swing.JLabel auteur;
    private javax.swing.JButton bajout;
    private javax.swing.JButton bajoutas;
    private javax.swing.JButton bexit;
    private javax.swing.JButton bimg;
    private javax.swing.JButton bimpress;
    private javax.swing.JButton bmodaas;
    private javax.swing.JButton bmodif;
    private javax.swing.JButton brech;
    private javax.swing.JButton bseearch;
    private javax.swing.JButton bsupp;
    private javax.swing.JButton bsuppas;
    private javax.swing.JComboBox cbfili;
    private javax.swing.JLabel descript;
    private javax.swing.JLabel disco;
    private javax.swing.JLabel edition;
    private javax.swing.JLabel filiere;
    private javax.swing.JLabel fond;
    private javax.swing.JLabel fond1;
    private javax.swing.JLabel fondetud;
    private javax.swing.JLabel intitulé;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTabbedPane jTabbedPane2;
    private javax.swing.JTextArea jadescri;
    private javax.swing.JTextField jadr;
    private com.toedter.calendar.JYearChooser jannee;
    private javax.swing.JTextField jemail;
    private javax.swing.JTextField jid;
    private javax.swing.JTextField jmdp;
    private javax.swing.JTextField jnom;
    private javax.swing.JTextField jpnom;
    private javax.swing.JTextField jtauteur;
    private javax.swing.JTextField jtedit;
    private javax.swing.JTextField jtintit;
    private javax.swing.JTextField jtpath;
    private javax.swing.JTextField jtquant;
    private javax.swing.JTextField jtrechas;
    private javax.swing.JTextField jtsearch;
    private javax.swing.JTextField jtype;
    private javax.swing.JPanel liste;
    private javax.swing.JPanel listeetud;
    private javax.swing.JLabel lphoto;
    private javax.swing.JLabel lref;
    private javax.swing.JLabel mail;
    private javax.swing.JLabel mdp;
    private javax.swing.JLabel nom;
    private javax.swing.JPanel ouvrages;
    private javax.swing.JLabel prenom;
    private javax.swing.JLabel reference;
    private javax.swing.JTable tabass;
    private javax.swing.JTable tabemp;
    private javax.swing.JTable tabouv;
    private javax.swing.JTable tabreserv;
    private javax.swing.JLabel titre;
    private javax.swing.JLabel titreas;
    // End of variables declaration//GEN-END:variables

    private void setIcon() {
        setIconImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("BIBLIO.png")));
    }
}
