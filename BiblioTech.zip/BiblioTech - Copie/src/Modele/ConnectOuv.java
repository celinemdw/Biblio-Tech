/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modele;

import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Lenovo
 */
public class ConnectOuv {

   public  ConnectBdd cono = new ConnectBdd();
    public PreparedStatement psto;
    public ResultSet rso;

    public ConnectOuv() {
        try {
            psto = cono.connexBd().prepareStatement("select * from ouvrages");
            rso = psto.executeQuery();
        } catch (SQLException ex) {
            Logger.getLogger(ConnectOuv.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

}
