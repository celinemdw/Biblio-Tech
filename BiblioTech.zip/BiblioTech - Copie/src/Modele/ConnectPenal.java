/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modele;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author Lenovo
 */
public class ConnectPenal {
    public ConnectBdd cop=new ConnectBdd();
    public PreparedStatement stat;
     public ResultSet rsp;
         public ConnectPenal(){
        try {
           stat= cop.connexBd().prepareStatement("select * from penalite");
           rsp= stat.executeQuery();
        } catch (SQLException ex) {
            Logger.getLogger(ConnectPenal.class.getName()).log(Level.SEVERE, null, ex);
        }
             
     
 }   
}
