/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modele;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author Lenovo
 */
public class ConnexionAssistant {
    public ConnectBdd connexas=new ConnectBdd();
    public PreparedStatement stat;
     public ResultSet rsas;
         public ConnexionAssistant(){
        try {
           stat= connexas.connexBd().prepareStatement("select * from assistant");
           rsas= stat.executeQuery();
        } catch (SQLException ex) {
            Logger.getLogger(ConnexionAssistant.class.getName()).log(Level.SEVERE, null, ex);
        }
             
     
 }   
}

