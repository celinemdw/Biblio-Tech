/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modele;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author Lenovo
 */
public class ConnectEmprunt {
    public ConnectBdd coemp=new ConnectBdd();
    public PreparedStatement stat;
     public ResultSet rsemp;
         public ConnectEmprunt(){
        try {
           stat= coemp.connexBd().prepareStatement("select * from emprunt");
           rsemp= stat.executeQuery();
        } catch (SQLException ex) {
            Logger.getLogger(ConnectEmprunt.class.getName()).log(Level.SEVERE, null, ex);
        }
             
     
 }   
}
