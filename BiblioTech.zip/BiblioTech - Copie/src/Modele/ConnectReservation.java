/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modele;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author Lenovo
 */
public class ConnectReservation {
    public ConnectBdd conreserv=new ConnectBdd();
    public PreparedStatement stat;
     public ResultSet rsreserv;
         public ConnectReservation(){
        try {
           stat= conreserv.connexBd().prepareStatement("select * from reservation");
           rsreserv= stat.executeQuery();
        } catch (SQLException ex) {
            Logger.getLogger(ConnectReservation.class.getName()).log(Level.SEVERE, null, ex);
        }
             
     
 }   
}
