/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modele;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author Lenovo
 */
public class ConnexEtudiant {
    public ConnectBdd connex=new ConnectBdd();
    public PreparedStatement stat;
     public ResultSet rset;
         public ConnexEtudiant(){
        try {
           stat= connex.connexBd().prepareStatement("select * from etudiant");
           rset= stat.executeQuery();
        } catch (SQLException ex) {
            Logger.getLogger(ConnexEtudiant.class.getName()).log(Level.SEVERE, null, ex);
        }
             
     
 }   
}
