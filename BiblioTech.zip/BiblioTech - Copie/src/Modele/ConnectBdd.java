/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modele;

import java.sql.*;
import javax.swing.JOptionPane;

/**
 *
 * @author Lenovo
 */
public class ConnectBdd {

    Connection connex;

    public ConnectBdd() {
        //connexion au server de base de donnée MySql
        try {
            //pour la connexion 
            Class.forName("com.mysql.jdbc.Driver");
         //  JOptionPane.showMessageDialog(null, "Connexion au server de Base de donnée faite avec succés");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Connexion echouhé au server de base de donnée" + e.getMessage());
        }
        //connexion a la base de donnée 
        try {
            connex = DriverManager.getConnection("jdbc:mysql://localhost:3306/biblio_tech", "root", "");
        //    JOptionPane.showMessageDialog(null, "Connexion a la base de donnée reussie");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Connexion a la base de donné echoué" + e.getMessage());
        }

    }

    //methode de connexion a la base de donnée

    public Connection connexBd() {
        return connex;
    }
    public static void main(String[] args) {
        ConnectBdd connect=new ConnectBdd();
        connect.connexBd();
    }

}
